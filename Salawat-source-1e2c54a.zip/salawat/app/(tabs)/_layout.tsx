import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform } from "react-native";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 58 + bottomPadding;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.tint,
        tabBarInactiveTintColor: colors.muted,
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarStyle: {
          paddingTop: 8,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          backgroundColor: colors.background,
          borderTopColor: colors.border,
          borderTopWidth: 0.5,
        },
        tabBarLabelStyle: { fontSize: 10, fontWeight: "700" },
      }}
    >
      <Tabs.Screen name="index" options={{ title: "Prières", tabBarIcon: ({ color }) => <IconSymbol size={24} name="calendar.badge.clock" color={color} /> }} />
      <Tabs.Screen name="mosques" options={{ title: "Mosquées", tabBarIcon: ({ color }) => <IconSymbol size={24} name="building.columns.fill" color={color} /> }} />
      <Tabs.Screen name="qibla" options={{ title: "Qibla", tabBarIcon: ({ color }) => <IconSymbol size={24} name="location.north.fill" color={color} /> }} />
      <Tabs.Screen name="quran" options={{ title: "Quran", tabBarIcon: ({ color }) => <IconSymbol size={24} name="book.closed.fill" color={color} /> }} />
      <Tabs.Screen name="profile" options={{ title: "Profil", tabBarIcon: ({ color }) => <IconSymbol size={24} name="person.crop.circle.fill" color={color} /> }} />
    </Tabs>
  );
}
