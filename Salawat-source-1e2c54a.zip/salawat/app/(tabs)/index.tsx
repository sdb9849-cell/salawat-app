import * as Location from "expo-location";
import { router, useFocusEffect } from "expo-router";
import { skipToken } from "@tanstack/react-query";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from "react-native";

import { SALAWAT_COLORS, type Mosque } from "@/constants/salawat";
import {
  Icon,
  MosqueCard,
  PageHeader,
  PrayerCard,
  SalawatMark,
  SectionTitle,
} from "@/components/salawat-ui";
import { ScreenContainer } from "@/components/screen-container";
import {
  getCurrentGpsLocation,
  getGpsLocationFromCoordinates,
  type CurrentGpsLocation,
} from "@/lib/current-location";
import { trpc } from "@/lib/trpc";
import {
  distanceBetweenMeters,
  type NearbyLocation,
  type NearbyMosque,
} from "@/lib/mosques-nearby";

function getLocalTimeParts(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat("fr-FR", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(date);
  return Object.fromEntries(
    parts
      .filter((part) => part.type !== "literal")
      .map((part) => [part.type, Number(part.value)]),
  ) as { hour: number; minute: number; second: number };
}

function formatApiDate(date: Date) {
  return `${String(date.getDate()).padStart(2, "0")}-${String(date.getMonth() + 1).padStart(2, "0")}-${date.getFullYear()}`;
}

function prayerMinutes(time: string) {
  const [hour, minute] = time.split(":").map(Number);
  return hour * 60 + minute;
}

function formatRemaining(seconds: number) {
  const safeSeconds = Math.max(0, seconds);
  const hours = Math.floor(safeSeconds / 3600);
  const minutes = Math.floor((safeSeconds % 3600) / 60);
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function toMosqueCard(mosque: NearbyMosque): Mosque {
  return {
    id: mosque.id,
    name: mosque.name,
    city: mosque.city,
    country: mosque.country,
    address: mosque.address,
    distance: mosque.distance,
    verified: mosque.verified,
    openNow: mosque.openNow,
    services: mosque.services,
    nextPrayer: mosque.nextPrayer,
    imageTone: mosque.imageTone,
  };
}

export default function HomeScreen() {
  const { width } = useWindowDimensions();
  const isWide = width >= 800;
  const [now, setNow] = useState(() => new Date());
  const [location, setLocation] = useState<CurrentGpsLocation | null>(null);
  const [locationError, setLocationError] = useState("");
  const [isLocating, setIsLocating] = useState(true);
  const [mosqueRadius, setMosqueRadius] = useState(5000);
  const lastLocationRef = useRef<NearbyLocation | null>(null);
  const refreshLocation = useCallback(async () => {
    setIsLocating(true);
    setLocationError("");
    try {
      const current = await getCurrentGpsLocation();
      lastLocationRef.current = current;
      setLocation(current);
      setMosqueRadius(5000);
    } catch (error) {
      setLocationError(
        error instanceof Error
          ? error.message
          : "La position GPS n’a pas pu être obtenue.",
      );
    } finally {
      setIsLocating(false);
    }
  }, []);

  useEffect(() => {
    const locationTimer = setTimeout(() => {
      void refreshLocation();
    }, 0);
    const timer = setInterval(() => setNow(new Date()), 30_000);
    return () => {
      clearTimeout(locationTimer);
      clearInterval(timer);
    };
  }, [refreshLocation]);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      let subscription: Location.LocationSubscription | undefined;
      const startLocationWatch = async () => {
        try {
          const permission = await Location.getForegroundPermissionsAsync();
          if (
            !active ||
            permission.status !== Location.PermissionStatus.GRANTED
          )
            return;
          subscription = await Location.watchPositionAsync(
            {
              accuracy: Location.Accuracy.Balanced,
              distanceInterval: 500,
              timeInterval: 5 * 60 * 1000,
            },
            (position) => {
              if (!active) return;
              const next = {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
                accuracy: position.coords.accuracy,
              };
              const previous = lastLocationRef.current;
              if (
                !Number.isFinite(next.latitude) ||
                !Number.isFinite(next.longitude) ||
                next.latitude < -90 ||
                next.latitude > 90 ||
                next.longitude < -180 ||
                next.longitude > 180 ||
                (previous && distanceBetweenMeters(previous, next) < 500)
              )
                return;
              lastLocationRef.current = next;
              void getGpsLocationFromCoordinates(
                next.latitude,
                next.longitude,
                next.accuracy,
              )
                .then((current) => {
                  if (active) {
                    setLocation(current);
                    setMosqueRadius(5000);
                  }
                })
                .catch(() => {
                  if (active)
                    setLocationError(
                      "La position a changé, mais son actualisation a échoué.",
                    );
                });
            },
          );
        } catch {
          if (active)
            setLocationError(
              "Le suivi de la position n’est pas disponible pour le moment.",
            );
        }
      };
      void startLocationWatch();
      return () => {
        active = false;
        subscription?.remove();
      };
    }, []),
  );

  const prayerDate = formatApiDate(now);
  const prayerQuery = trpc.mosques.prayerTimes.useQuery(
    location
      ? {
          latitude: location.latitude,
          longitude: location.longitude,
          date: prayerDate,
          countryCode: location.countryCode,
          school: 0,
        }
      : skipToken,
    { staleTime: 5 * 60 * 1000, retry: 1 },
  );
  const mosqueQuery = trpc.mosques.nearby.useQuery(
    location
      ? {
          latitude: location.latitude,
          longitude: location.longitude,
          radiusMeters: mosqueRadius,
        }
      : skipToken,
    { staleTime: 5 * 60 * 1000, retry: 1 },
  );
  useEffect(() => {
    if (!location || !mosqueQuery.data || mosqueQuery.data.length > 0) return;
    const nextRadius = [10000, 20000].find((radius) => radius > mosqueRadius);
    if (!nextRadius) return;
    const timer = setTimeout(() => setMosqueRadius(nextRadius), 250);
    return () => clearTimeout(timer);
  }, [location, mosqueQuery.data, mosqueRadius]);

  const timeZone =
    prayerQuery.data?.timezone ||
    Intl.DateTimeFormat().resolvedOptions().timeZone ||
    "UTC";
  const timeParts = getLocalTimeParts(now, timeZone);
  const currentSeconds =
    timeParts.hour * 3600 + timeParts.minute * 60 + timeParts.second;
  const prayers = prayerQuery.data?.prayers ?? [];
  const nextIndex = prayers.findIndex(
    (prayer) => prayerMinutes(prayer.time) * 60 > currentSeconds,
  );
  const resolvedNextIndex = nextIndex >= 0 ? nextIndex : 0;
  const nextPrayer = prayers[resolvedNextIndex];
  const nextTarget = nextPrayer
    ? prayerMinutes(nextPrayer.time) * 60 + (nextIndex < 0 ? 24 * 3600 : 0)
    : 0;
  const remainingSeconds = nextPrayer ? nextTarget - currentSeconds : null;
  const previousIndex =
    resolvedNextIndex === 0 ? prayers.length - 1 : resolvedNextIndex - 1;
  const previousPrayer = prayers[previousIndex];
  const previousTarget = previousPrayer
    ? prayerMinutes(previousPrayer.time) * 60 +
      (resolvedNextIndex === 0 ? -24 * 3600 : 0)
    : 0;
  const prayerWindow = Math.max(1, nextTarget - previousTarget);
  const dayProgress = nextPrayer
    ? Math.min(
        100,
        Math.max(0, ((currentSeconds - previousTarget) / prayerWindow) * 100),
      )
    : 0;
  const displayedPrayers = prayers.map((prayer, index) => ({
    ...prayer,
    state:
      index < resolvedNextIndex
        ? ("done" as const)
        : index === resolvedNextIndex
          ? ("next" as const)
          : ("upcoming" as const),
  }));
  const nearbyMosques = mosqueQuery.data ?? [];
  const dateLabel = useMemo(
    () =>
      new Intl.DateTimeFormat("fr-FR", { timeZone, dateStyle: "full" }).format(
        now,
      ),
    [now, timeZone],
  );

  return (
    <ScreenContainer
      containerClassName="bg-background"
      safeAreaClassName="bg-background"
    >
      <ScrollView
        contentContainerStyle={[styles.content, isWide && styles.contentWide]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topBar}>
          <View style={styles.brandRow}>
            <SalawatMark size={40} />
            <View>
              <Text style={styles.brandName}>Salawat</Text>
              <Text style={styles.brandTagline}>
                Votre journée, guidée par la prière
              </Text>
            </View>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Ouvrir le profil et les notifications"
            style={styles.iconButton}
            onPress={() => router.push("/profile")}
          >
            <Icon
              name="notifications-none"
              size={21}
              color={SALAWAT_COLORS.emerald}
            />
            <View style={styles.notificationDot} />
          </Pressable>
        </View>

        <PageHeader
          eyebrow={`Aujourd’hui · ${dateLabel}`}
          title={`As-salāmu ʿalaykum`}
          description={
            location
              ? `Position actuelle · ${location.label}`
              : isLocating
                ? "Détection de votre position GPS…"
                : "Activez la localisation pour afficher les horaires de votre zone."
          }
          right={
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Changer de localisation, actuellement ${location?.label ?? "non définie"}`}
              style={styles.locationChip}
              onPress={() => router.push("/mosques")}
            >
              <Icon
                name="location-on"
                size={15}
                color={SALAWAT_COLORS.emerald}
              />
              <Text style={styles.locationText} numberOfLines={1}>
                {location?.label ?? "Localiser"}
              </Text>
              <Icon
                name="expand-more"
                size={17}
                color={SALAWAT_COLORS.emerald}
              />
            </Pressable>
          }
        />

        <View style={[styles.heroRow, isWide && styles.heroRowWide]}>
          <View style={styles.nextPrayerCard}>
            <View style={styles.heroTopLine}>
              <View>
                <Text style={styles.heroEyebrow}>PROCHAINE PRIÈRE</Text>
                <Text style={styles.heroPrayerName}>
                  {nextPrayer?.name ??
                    (prayerQuery.isLoading ? "…" : "Indisponible")}
                </Text>
              </View>
              <View style={styles.heroIconBubble}>
                <Icon
                  name="schedule"
                  size={21}
                  color={SALAWAT_COLORS.goldSoft}
                />
              </View>
            </View>
            <View style={styles.heroBottomLine}>
              <View>
                <Text style={styles.heroTime}>
                  {nextPrayer?.time ?? "--:--"}
                </Text>
                <Text style={styles.heroMeta}>
                  {remainingSeconds === null
                    ? "Horaires à charger"
                    : `dans ${formatRemaining(remainingSeconds)}`}{" "}
                  · {location?.label ?? "Position inconnue"}
                </Text>
              </View>
              <View style={styles.countdownBadge}>
                <Text style={styles.countdownValue}>
                  {remainingSeconds === null
                    ? "--:--"
                    : formatRemaining(remainingSeconds)}
                </Text>
                <Text style={styles.countdownLabel}>restant</Text>
              </View>
            </View>
            <View style={styles.heroProgressTrack}>
              <View
                style={[styles.heroProgressFill, { width: `${dayProgress}%` }]}
              />
            </View>
          </View>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Ouvrir la direction de la Qibla"
            style={styles.qiblaShortcut}
            onPress={() => router.push("/qibla")}
          >
            <View style={styles.qiblaCompass}>
              <Icon name="explore" size={28} color={SALAWAT_COLORS.gold} />
            </View>
            <View style={styles.qiblaCopy}>
              <Text style={styles.qiblaKicker}>OUTIL SPIRITUEL</Text>
              <Text style={styles.qiblaTitle}>Trouver la Qibla</Text>
              <Text style={styles.qiblaDetail}>
                Direction depuis {location?.label ?? "votre position"}
              </Text>
            </View>
            <Icon
              name="arrow-forward"
              size={20}
              color={SALAWAT_COLORS.emerald}
            />
          </Pressable>
        </View>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Ouvrir le Quran"
          style={styles.quranBanner}
          onPress={() => router.push("/quran")}
        >
          <View style={styles.quranBannerIcon}>
            <Icon name="menu-book" size={21} color={SALAWAT_COLORS.gold} />
          </View>
          <View style={styles.quranBannerCopy}>
            <Text style={styles.quranBannerKicker}>LECTURE DU JOUR</Text>
            <Text style={styles.quranBannerTitle}>Ouvrir le Quran</Text>
            <Text style={styles.quranBannerDetail}>
              Lisez une sourate et continuez votre parcours.
            </Text>
          </View>
          <Icon name="arrow-forward" size={20} color={SALAWAT_COLORS.emerald} />
        </Pressable>

        <SectionTitle title="Horaires du jour" />
        {locationError && !location ? (
          <View style={styles.statusRow}>
            <Text style={styles.errorMessage}>{locationError}</Text>
            <Pressable
              style={styles.retryButton}
              onPress={() => void refreshLocation()}
            >
              <Text style={styles.retryText}>Réessayer</Text>
            </Pressable>
          </View>
        ) : null}
        {prayerQuery.isError ? (
          <View style={styles.statusRow}>
            <Text style={styles.errorMessage}>
              {prayerQuery.error.message ||
                "Les horaires n’ont pas pu être chargés."}
            </Text>
            <Pressable
              style={styles.retryButton}
              onPress={() => void prayerQuery.refetch()}
            >
              <Text style={styles.retryText}>Réessayer</Text>
            </Pressable>
          </View>
        ) : null}
        {location && prayerQuery.isLoading ? (
          <Text style={styles.statusMessage}>
            Calcul des horaires à partir de votre position…
          </Text>
        ) : null}
        {displayedPrayers.length > 0 ? (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.prayersRow}
          >
            {displayedPrayers.map((prayer) => (
              <PrayerCard key={prayer.name} prayer={prayer} />
            ))}
          </ScrollView>
        ) : null}
        {prayerQuery.data ? (
          <Text style={styles.statusMessage}>
            Calcul : {prayerQuery.data.methodName} · Fuseau :{" "}
            {prayerQuery.data.timezone || timeZone}
          </Text>
        ) : null}

        <View style={styles.sectionGap} />
        <SectionTitle
          title="Mosquées à proximité"
          action="Voir tout"
          onPress={() => router.push("/mosques")}
        />
        {mosqueQuery.isError ? (
          <View style={styles.statusRow}>
            <Text style={styles.errorMessage}>
              {mosqueQuery.error.message ||
                "Les mosquées proches ne sont pas disponibles."}
            </Text>
            <Pressable
              style={styles.retryButton}
              onPress={() => void mosqueQuery.refetch()}
            >
              <Text style={styles.retryText}>Réessayer</Text>
            </Pressable>
          </View>
        ) : null}
        {location && mosqueQuery.isFetching ? (
          <Text style={styles.statusMessage}>
            Recherche des mosquées dans un rayon de {mosqueRadius / 1000} km…
          </Text>
        ) : null}
        {nearbyMosques.slice(0, 2).map((mosque) => (
          <MosqueCard
            key={mosque.id}
            mosque={toMosqueCard(mosque)}
            onPress={() => router.push("/mosques")}
          />
        ))}
        {location &&
        mosqueQuery.isSuccess &&
        nearbyMosques.length === 0 &&
        mosqueRadius >= 20000 ? (
          <Text style={styles.statusMessage}>
            Aucune mosquée trouvée dans un rayon de 20 km. Les données
            OpenStreetMap peuvent être incomplètes.
          </Text>
        ) : null}

        <Pressable
          style={styles.manageBanner}
          onPress={() => router.push("/manage")}
        >
          <View style={styles.manageBannerIcon}>
            <Icon
              name="admin-panel-settings"
              size={22}
              color={SALAWAT_COLORS.gold}
            />
          </View>
          <View style={styles.manageCopy}>
            <Text style={styles.manageTitle}>Vous gérez une mosquée ?</Text>
            <Text style={styles.manageDetail}>
              Mettez à jour les horaires et informations de votre communauté.
            </Text>
          </View>
          <Icon name="chevron-right" size={21} color={SALAWAT_COLORS.emerald} />
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 18,
    paddingTop: 18,
    paddingBottom: 110,
    maxWidth: 760,
    width: "100%",
    alignSelf: "center",
  },
  contentWide: { paddingHorizontal: 28 },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 25,
  },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandName: {
    color: SALAWAT_COLORS.ink,
    fontSize: 19,
    fontWeight: "900",
    letterSpacing: -0.3,
  },
  brandTagline: { color: SALAWAT_COLORS.muted, fontSize: 10, marginTop: 2 },
  iconButton: {
    width: 42,
    height: 42,
    borderRadius: 15,
    backgroundColor: SALAWAT_COLORS.white,
    borderWidth: 1,
    borderColor: SALAWAT_COLORS.line,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  notificationDot: {
    position: "absolute",
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: SALAWAT_COLORS.gold,
    top: 9,
    right: 10,
    borderWidth: 1.5,
    borderColor: SALAWAT_COLORS.white,
  },
  locationChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: SALAWAT_COLORS.emeraldSoft,
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 7,
    marginTop: 4,
  },
  locationText: {
    color: SALAWAT_COLORS.emerald,
    fontSize: 12,
    fontWeight: "800",
    maxWidth: 105,
  },
  heroRow: { gap: 11, marginBottom: 26 },
  heroRowWide: { flexDirection: "row", alignItems: "stretch" },
  nextPrayerCard: {
    flex: 1.5,
    backgroundColor: SALAWAT_COLORS.emerald,
    borderRadius: 24,
    padding: 19,
    minHeight: 196,
    overflow: "hidden",
  },
  heroTopLine: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  heroEyebrow: {
    color: "#A8D7C6",
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.3,
  },
  heroPrayerName: {
    color: SALAWAT_COLORS.white,
    fontSize: 27,
    fontWeight: "900",
    marginTop: 5,
  },
  heroIconBubble: {
    width: 42,
    height: 42,
    borderRadius: 15,
    backgroundColor: "rgba(255,255,255,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  heroBottomLine: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    flex: 1,
    marginTop: 20,
  },
  heroTime: {
    color: SALAWAT_COLORS.white,
    fontSize: 38,
    fontWeight: "900",
    letterSpacing: -1,
  },
  heroMeta: { color: "#BCE1D3", fontSize: 11, marginTop: 2 },
  countdownBadge: { alignItems: "flex-end" },
  countdownValue: {
    color: SALAWAT_COLORS.goldSoft,
    fontSize: 20,
    fontWeight: "900",
  },
  countdownLabel: { color: "#A8D7C6", fontSize: 10, marginTop: 1 },
  heroProgressTrack: {
    height: 5,
    borderRadius: 3,
    backgroundColor: "rgba(255,255,255,0.15)",
    marginTop: 17,
    overflow: "hidden",
  },
  heroProgressFill: {
    height: "100%",
    width: "62%",
    backgroundColor: SALAWAT_COLORS.gold,
  },
  qiblaShortcut: {
    flex: 1,
    backgroundColor: SALAWAT_COLORS.white,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: SALAWAT_COLORS.line,
    padding: 17,
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    minHeight: 104,
  },
  qiblaCompass: {
    width: 48,
    height: 48,
    borderRadius: 17,
    backgroundColor: SALAWAT_COLORS.goldSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  qiblaCopy: { flex: 1 },
  qiblaKicker: {
    color: SALAWAT_COLORS.gold,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.1,
  },
  qiblaTitle: {
    color: SALAWAT_COLORS.ink,
    fontSize: 15,
    fontWeight: "900",
    marginTop: 4,
  },
  qiblaDetail: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 3 },
  quranBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    backgroundColor: "#F4EFE3",
    borderRadius: 18,
    padding: 13,
    marginBottom: 25,
  },
  quranBannerIcon: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: SALAWAT_COLORS.goldSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  quranBannerCopy: { flex: 1 },
  quranBannerKicker: {
    color: SALAWAT_COLORS.gold,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.1,
  },
  quranBannerTitle: {
    color: SALAWAT_COLORS.ink,
    fontSize: 14,
    fontWeight: "900",
    marginTop: 3,
  },
  quranBannerDetail: {
    color: SALAWAT_COLORS.muted,
    fontSize: 11,
    marginTop: 2,
  },
  prayersRow: { flexDirection: "row", gap: 8, paddingRight: 4 },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#FFF3E6",
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
  },
  statusMessage: {
    color: SALAWAT_COLORS.muted,
    fontSize: 11,
    lineHeight: 16,
    marginVertical: 8,
  },
  errorMessage: {
    flex: 1,
    color: SALAWAT_COLORS.ink,
    fontSize: 11,
    lineHeight: 16,
  },
  retryButton: {
    backgroundColor: SALAWAT_COLORS.emeraldSoft,
    borderRadius: 12,
    paddingHorizontal: 11,
    paddingVertical: 8,
  },
  retryText: { color: SALAWAT_COLORS.emerald, fontSize: 11, fontWeight: "900" },
  sectionGap: { height: 25 },
  manageBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    padding: 14,
    marginTop: 10,
    backgroundColor: "#F4EFE3",
    borderRadius: 18,
  },
  manageBannerIcon: {
    width: 39,
    height: 39,
    borderRadius: 13,
    backgroundColor: SALAWAT_COLORS.goldSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  manageCopy: { flex: 1 },
  manageTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  manageDetail: {
    color: SALAWAT_COLORS.muted,
    fontSize: 11,
    lineHeight: 16,
    marginTop: 3,
  },
});
