import * as Location from "expo-location";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { skipToken } from "@tanstack/react-query";

import { SALAWAT_COLORS, type Mosque } from "@/constants/salawat";
import { Icon, MosqueCard, PageHeader, Pill } from "@/components/salawat-ui";
import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";
import {
  cacheKey,
  distanceBetweenMeters,
  readNearbyCache,
  writeNearbyCache,
  type NearbyLocation,
  type NearbyMosque,
} from "@/lib/mosques-nearby";
import { getCurrentGpsLocation } from "@/lib/current-location";

const RADIUS_OPTIONS = [1000, 3000, 5000, 10000, 20000];
const FILTERS = [
  "Près de moi",
  "Favoris",
  "Ouvertes",
  "Jumu'ah",
  "Qur’an",
  "Femmes",
];

type LocationState = NearbyLocation & {
  label: string;
  source: "gps" | "manual";
  countryCode?: string;
};

function toMosqueCard(mosque: NearbyMosque): Mosque {
  return {
    id: mosque.id,
    name: mosque.name,
    city: mosque.city,
    country: mosque.country,
    address: mosque.address,
    distance: mosque.distance,
    verified: mosque.verified,
    openNow: mosque.openNow,
    services: mosque.services,
    nextPrayer: mosque.nextPrayer,
    imageTone: mosque.imageTone,
  };
}

export default function MosquesScreen() {
  const [query, setQuery] = useState("");
  const [selectedFilter, setSelectedFilter] = useState("Près de moi");
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [radiusMeters, setRadiusMeters] = useState(5000);
  const [location, setLocation] = useState<LocationState | null>(null);
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [locationError, setLocationError] = useState("");
  const [cachedMosques, setCachedMosques] = useState<NearbyMosque[]>([]);
  const [cacheSavedAt, setCacheSavedAt] = useState<string | null>(null);
  const [isRefreshingLocation, setIsRefreshingLocation] = useState(false);
  const lastPublishedLocation = useRef<NearbyLocation | null>(null);
  const { width } = useWindowDimensions();
  const isWide = width >= 800;

  const publishPosition = useCallback(
    (position: NearbyLocation) => {
      const nextLocation = {
        latitude: position.latitude,
        longitude: position.longitude,
        accuracy: position.accuracy,
      };
      if (
        !Number.isFinite(nextLocation.latitude) ||
        !Number.isFinite(nextLocation.longitude) ||
        nextLocation.latitude < -90 ||
        nextLocation.latitude > 90 ||
        nextLocation.longitude < -180 ||
        nextLocation.longitude > 180
      ) {
        setLocationError(
          "Le GPS a renvoyé des coordonnées invalides. Vérifiez que la localisation est activée.",
        );
        return;
      }
      const previous = lastPublishedLocation.current;
      if (
        previous &&
        location?.source === "gps" &&
        distanceBetweenMeters(previous, nextLocation) < 250
      )
        return;
      lastPublishedLocation.current = nextLocation;
      setPermissionDenied(false);
      setLocation({
        ...nextLocation,
        label: "Position actuelle",
        source: "gps",
      });
      setLocationError("");
    },
    [location?.source],
  );

  const requestLocation = useCallback(async () => {
    setIsRefreshingLocation(true);
    setLocationError("");
    try {
      const current = await getCurrentGpsLocation();
      if (
        !Number.isFinite(current.latitude) ||
        !Number.isFinite(current.longitude)
      ) {
        throw new Error("Les coordonnées GPS reçues sont invalides.");
      }
      const nextLocation = {
        latitude: current.latitude,
        longitude: current.longitude,
        accuracy: current.accuracy,
      };
      lastPublishedLocation.current = nextLocation;
      setPermissionDenied(false);
      setLocation({
        ...nextLocation,
        label: current.label,
        source: "gps",
        countryCode: current.countryCode,
      });
      setLocationError("");
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "La position n’a pas pu être obtenue.";
      if (
        message.toLowerCase().includes("autorisation") ||
        message.toLowerCase().includes("refus")
      ) {
        setPermissionDenied(true);
      }
      setLocationError(
        `${message} Vous pouvez rechercher une ville ou un code postal.`,
      );
    } finally {
      setIsRefreshingLocation(false);
    }
  }, []);

  useEffect(() => {
    AsyncStorage.getItem("salawat.mosques.favorites")
      .then((value) => {
        if (!value) return;
        try {
          const parsed = JSON.parse(value);
          if (Array.isArray(parsed))
            setFavoriteIds(
              parsed.filter((item): item is string => typeof item === "string"),
            );
        } catch {
          // Ignore malformed local state.
        }
      })
      .catch(() => undefined);
    const locationTimer = setTimeout(() => {
      void requestLocation();
    }, 0);
    return () => clearTimeout(locationTimer);
  }, [requestLocation]);

  useFocusEffect(
    useCallback(() => {
      let subscription: Location.LocationSubscription | undefined;
      let cancelled = false;
      const startMovementUpdates = async () => {
        const permission = await Location.getForegroundPermissionsAsync();
        if (
          cancelled ||
          permission.status !== Location.PermissionStatus.GRANTED
        )
          return;
        subscription = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.Balanced,
            distanceInterval: 500,
            timeInterval: 5 * 60 * 1000,
          },
          (position) => {
            if (!cancelled) publishPosition(position.coords);
          },
        );
      };
      void startMovementUpdates();
      return () => {
        cancelled = true;
        subscription?.remove();
      };
    }, [publishPosition]),
  );

  const nearbyQuery = trpc.mosques.nearby.useQuery(
    location
      ? {
          latitude: location.latitude,
          longitude: location.longitude,
          radiusMeters,
        }
      : skipToken,
    { staleTime: 5 * 60 * 1000, retry: 1 },
  );
  const manualLocationQuery = trpc.mosques.searchLocation.useQuery(
    query.trim().length >= 2 ? { query: query.trim() } : skipToken,
    { enabled: false, retry: false },
  );

  useEffect(() => {
    if (!location) return;
    const key = cacheKey(location, radiusMeters);
    let active = true;
    const clearCacheTimer = setTimeout(() => {
      if (!active) return;
      setCachedMosques([]);
      setCacheSavedAt(null);
    }, 0);
    readNearbyCache(key).then((cached) => {
      if (active && cached) {
        setCachedMosques(cached.data);
        setCacheSavedAt(cached.savedAt);
      }
    });
    return () => {
      active = false;
      clearTimeout(clearCacheTimer);
    };
  }, [location, radiusMeters]);

  useEffect(() => {
    if (!location || !nearbyQuery.data || nearbyQuery.data.length > 0) return;
    const nextRadius = RADIUS_OPTIONS.find((radius) => radius > radiusMeters);
    if (!nextRadius) return;
    const timer = setTimeout(() => setRadiusMeters(nextRadius), 250);
    return () => clearTimeout(timer);
  }, [location, nearbyQuery.data, radiusMeters]);

  useEffect(() => {
    if (!nearbyQuery.data || !location) return;
    const key = cacheKey(location, radiusMeters);
    writeNearbyCache(key, nearbyQuery.data);
  }, [nearbyQuery.data, location, radiusMeters]);

  const remoteMosques = nearbyQuery.data ?? cachedMosques;
  const isUsingCache = !nearbyQuery.data && cachedMosques.length > 0;

  const toggleFavorite = (id: string) => {
    setFavoriteIds((current) => {
      const next = current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id];
      AsyncStorage.setItem(
        "salawat.mosques.favorites",
        JSON.stringify(next),
      ).catch(() => undefined);
      return next;
    });
  };

  const manualSearch = async () => {
    if (query.trim().length < 2) return;
    setLocationError("");
    try {
      const result = await manualLocationQuery.refetch();
      if (!result.data) {
        setLocationError(
          "Lieu introuvable. Essayez une ville ou un code postal plus précis.",
        );
        return;
      }
      setPermissionDenied(false);
      lastPublishedLocation.current = null;
      setLocation({
        latitude: result.data.latitude,
        longitude: result.data.longitude,
        label: result.data.label.split(",").slice(0, 2).join(","),
        source: "manual",
      });
      setQuery("");
    } catch {
      setLocationError(
        "La recherche du lieu a échoué. Vérifiez votre connexion et réessayez.",
      );
    }
  };

  const openDirections = (mosque: NearbyMosque) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${mosque.latitude},${mosque.longitude}&destination_place_id=${encodeURIComponent(mosque.sourceId ?? mosque.id)}`;
    Linking.openURL(url).catch(() => undefined);
  };

  const displayMosques = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    const source = location ? remoteMosques : [];
    return source
      .filter((mosque) => {
        const matchesQuery =
          !normalized ||
          `${mosque.name} ${mosque.city} ${mosque.country} ${mosque.address}`
            .toLowerCase()
            .includes(normalized);
        const matchesFilter =
          selectedFilter === "Près de moi" ||
          (selectedFilter === "Favoris" && favoriteIds.includes(mosque.id)) ||
          (selectedFilter === "Ouvertes" && mosque.openNow) ||
          (selectedFilter === "Jumu'ah" &&
            mosque.services.includes("Jumu'ah")) ||
          (selectedFilter === "Qur’an" && mosque.services.includes("Qur’an")) ||
          (selectedFilter === "Femmes" && mosque.services.includes("Femmes"));
        return matchesQuery && matchesFilter;
      })
      .sort((a, b) => (a.distanceMeters ?? 0) - (b.distanceMeters ?? 0));
  }, [favoriteIds, location, query, remoteMosques, selectedFilter]);

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={[styles.content, isWide && styles.contentWide]}
        showsVerticalScrollIndicator={false}
      >
        <PageHeader
          eyebrow="Communauté mondiale"
          title="Mosquées"
          description="Retrouvez un lieu de prière près de vous, avec des données communautaires clairement identifiées."
          right={
            <View style={styles.mapButton}>
              <Icon name="map" size={18} color={SALAWAT_COLORS.emerald} />
              <Text style={styles.mapText}>Carte</Text>
            </View>
          }
        />

        <View style={styles.searchBox}>
          <Icon name="search" size={21} color={SALAWAT_COLORS.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={manualSearch}
            placeholder="Ville, code postal ou mosquée"
            placeholderTextColor={SALAWAT_COLORS.muted}
            style={styles.searchInput}
            returnKeyType="search"
          />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Rechercher ce lieu"
            style={styles.searchButton}
            onPress={manualSearch}
          >
            <Icon name="arrow-forward" size={18} color={SALAWAT_COLORS.white} />
          </Pressable>
        </View>

        <View style={styles.locationNotice}>
          <View style={styles.locationIcon}>
            <Icon
              name={permissionDenied ? "location-off" : "my-location"}
              size={17}
              color={SALAWAT_COLORS.emerald}
            />
          </View>
          <View style={styles.locationCopy}>
            <Text style={styles.locationTitle}>
              {location?.label ?? "Localisation non définie"}
            </Text>
            <Text style={styles.locationDetail}>
              {location
                ? `Rayon de recherche · ${radiusMeters / 1000} km${location.source === "manual" ? " · recherche manuelle" : " · GPS actualisé après 500 m"}`
                : isRefreshingLocation
                  ? "Obtention de votre position GPS…"
                  : "Autorisez le GPS ou recherchez une ville"}
            </Text>
          </View>
          <Pressable
            onPress={requestLocation}
            disabled={isRefreshingLocation}
            hitSlop={10}
          >
            <Icon name="refresh" size={20} color={SALAWAT_COLORS.muted} />
          </Pressable>
        </View>

        {locationError ? (
          <View style={styles.warning}>
            <Icon name="info-outline" size={18} color={SALAWAT_COLORS.gold} />
            <Text style={styles.warningText}>{locationError}</Text>
          </View>
        ) : null}
        {nearbyQuery.isError ? (
          <View style={styles.warning}>
            <Icon name="cloud-off" size={18} color={SALAWAT_COLORS.gold} />
            <Text style={styles.warningText}>
              {nearbyQuery.error.message ||
                "Impossible de charger les mosquées."}
              {isUsingCache
                ? " Les derniers résultats enregistrés sont affichés."
                : " Vérifiez votre connexion puis réessayez."}
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => void nearbyQuery.refetch()}
            >
              <Text style={styles.inlineAction}>Réessayer</Text>
            </Pressable>
          </View>
        ) : null}
        {isUsingCache ? (
          <Text style={styles.cacheNotice}>
            Hors ligne · dernières mosquées enregistrées
            {cacheSavedAt
              ? ` le ${new Date(cacheSavedAt).toLocaleDateString("fr-FR")}`
              : ""}
          </Text>
        ) : null}

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filters}
        >
          {FILTERS.map((filter) => (
            <Pill
              key={filter}
              selected={selectedFilter === filter}
              onPress={() => setSelectedFilter(filter)}
            >
              {filter}
            </Pill>
          ))}
        </ScrollView>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.radiusFilters}
        >
          {RADIUS_OPTIONS.map((value) => (
            <Pill
              key={value}
              selected={radiusMeters === value}
              onPress={() => setRadiusMeters(value)}
            >
              {value / 1000} km
            </Pill>
          ))}
        </ScrollView>

        <View style={styles.resultHeader}>
          <Text style={styles.resultCount}>
            {isRefreshingLocation || !location
              ? "Localisation en cours…"
              : nearbyQuery.isFetching
                ? "Recherche en cours…"
                : nearbyQuery.data?.length === 0 &&
                    RADIUS_OPTIONS.some((radius) => radius > radiusMeters)
                  ? "Recherche dans un rayon plus large…"
                  : nearbyQuery.isError && displayMosques.length === 0
                    ? "Résultats indisponibles"
                    : `${displayMosques.length} lieux trouvés`}
          </Text>
          <Text style={styles.resultHint}>Tri · Distance</Text>
        </View>
        {displayMosques.map((mosque) => {
          const card = toMosqueCard(mosque as NearbyMosque);
          return (
            <View key={mosque.id}>
              <MosqueCard
                key={mosque.id}
                mosque={card}
                onPress={() =>
                  mosque.source === "osm"
                    ? openDirections(mosque as NearbyMosque)
                    : router.push({
                        pathname: "/mosque/[id]",
                        params: { id: mosque.id },
                      })
                }
                favorite={favoriteIds.includes(mosque.id)}
                onToggleFavorite={() => toggleFavorite(mosque.id)}
              />
              {mosque.source === "osm" ? (
                <Text style={styles.sourceNote}>
                  Source communautaire · {mosque.sourceLabel} ·{" "}
                  <Pressable
                    onPress={() => openDirections(mosque as NearbyMosque)}
                  >
                    <Text style={styles.inlineAction}>Itinéraire</Text>
                  </Pressable>
                </Text>
              ) : null}
            </View>
          );
        })}
        {location &&
        !nearbyQuery.isFetching &&
        nearbyQuery.isSuccess &&
        nearbyQuery.data?.length === 0 &&
        !RADIUS_OPTIONS.some((radius) => radius > radiusMeters) &&
        displayMosques.length === 0 ? (
          <View style={styles.emptyState}>
            <Icon name="search-off" size={30} color={SALAWAT_COLORS.muted} />
            <Text style={styles.emptyTitle}>
              Aucune mosquée trouvée dans un rayon de 20 km
            </Text>
            <Text style={styles.emptyDetail}>
              Les données OSM peuvent être incomplètes. Recherchez une ville
              voisine ou essayez plus tard.
            </Text>
            <Pressable style={styles.addButton} onPress={() => setQuery("")}>
              <Text style={styles.addButtonText}>Rechercher ailleurs</Text>
            </Pressable>
          </View>
        ) : null}

        <View style={styles.worldCard}>
          <View style={styles.worldIcon}>
            <Icon name="public" size={24} color={SALAWAT_COLORS.gold} />
          </View>
          <View style={styles.worldCopy}>
            <Text style={styles.worldTitle}>
              Une mosquée manque à l’appel ?
            </Text>
            <Text style={styles.worldDetail}>
              Les données OSM sont communautaires. Vérifiez et enrichissez la
              carte.
            </Text>
          </View>
          <Text style={styles.worldAction}>Ajouter</Text>
        </View>
        <Text style={styles.attribution}>
          Carte et données de lieux : OpenStreetMap contributors · les horaires
          restent à vérifier auprès de chaque mosquée.
        </Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 18,
    paddingTop: 18,
    paddingBottom: 110,
    maxWidth: 760,
    width: "100%",
    alignSelf: "center",
  },
  contentWide: { paddingHorizontal: 28 },
  mapButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: SALAWAT_COLORS.emeraldSoft,
    borderRadius: 18,
    paddingHorizontal: 11,
    paddingVertical: 8,
    marginTop: 5,
  },
  mapText: { color: SALAWAT_COLORS.emerald, fontSize: 12, fontWeight: "800" },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    backgroundColor: SALAWAT_COLORS.white,
    borderWidth: 1,
    borderColor: SALAWAT_COLORS.line,
    borderRadius: 17,
    paddingLeft: 14,
    paddingRight: 7,
    height: 54,
  },
  searchInput: { flex: 1, color: SALAWAT_COLORS.ink, fontSize: 13 },
  searchButton: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: SALAWAT_COLORS.emerald,
    alignItems: "center",
    justifyContent: "center",
  },
  locationNotice: {
    backgroundColor: "#EAF3EF",
    borderRadius: 17,
    marginTop: 12,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  locationIcon: {
    width: 35,
    height: 35,
    borderRadius: 12,
    backgroundColor: SALAWAT_COLORS.white,
    alignItems: "center",
    justifyContent: "center",
  },
  locationCopy: { flex: 1 },
  locationTitle: { color: SALAWAT_COLORS.ink, fontSize: 12, fontWeight: "800" },
  locationDetail: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 3 },
  warning: {
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    backgroundColor: SALAWAT_COLORS.goldSoft,
    borderRadius: 12,
    padding: 10,
    marginTop: 10,
  },
  warningText: {
    flex: 1,
    color: SALAWAT_COLORS.ink,
    fontSize: 11,
    lineHeight: 16,
  },
  cacheNotice: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 10 },
  filters: { gap: 8, paddingTop: 18, paddingBottom: 9 },
  radiusFilters: { gap: 8, paddingBottom: 18 },
  resultHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  resultCount: { color: SALAWAT_COLORS.ink, fontSize: 14, fontWeight: "900" },
  resultHint: { color: SALAWAT_COLORS.muted, fontSize: 11 },
  sourceNote: {
    color: SALAWAT_COLORS.muted,
    fontSize: 10,
    marginTop: -5,
    marginBottom: 9,
    paddingLeft: 65,
  },
  inlineAction: { color: SALAWAT_COLORS.emerald, fontWeight: "800" },
  emptyState: {
    alignItems: "center",
    padding: 40,
    backgroundColor: SALAWAT_COLORS.white,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: SALAWAT_COLORS.line,
  },
  emptyTitle: {
    color: SALAWAT_COLORS.ink,
    fontSize: 16,
    fontWeight: "900",
    marginTop: 10,
  },
  emptyDetail: {
    color: SALAWAT_COLORS.muted,
    fontSize: 12,
    marginTop: 4,
    textAlign: "center",
    lineHeight: 18,
  },
  addButton: {
    backgroundColor: SALAWAT_COLORS.emeraldSoft,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginTop: 16,
  },
  addButtonText: {
    color: SALAWAT_COLORS.emerald,
    fontSize: 12,
    fontWeight: "800",
  },
  worldCard: {
    backgroundColor: "#F4EFE3",
    borderRadius: 18,
    padding: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    marginTop: 8,
  },
  worldIcon: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: SALAWAT_COLORS.goldSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  worldCopy: { flex: 1 },
  worldTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  worldDetail: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 3 },
  worldAction: {
    color: SALAWAT_COLORS.emerald,
    fontSize: 12,
    fontWeight: "900",
  },
  attribution: {
    color: SALAWAT_COLORS.muted,
    fontSize: 10,
    lineHeight: 15,
    textAlign: "center",
    marginTop: 14,
  },
});
