import { router } from "expo-router";
import { useEffect, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAudioPlayer, useAudioPlayerStatus } from "@/lib/audio-player";

import { SALAWAT_COLORS, currentLocation, managedMosque } from "@/constants/salawat";
import { Icon, PageHeader, SalawatMark } from "@/components/salawat-ui";
import { ScreenContainer } from "@/components/screen-container";
import * as Auth from "@/lib/_core/auth";
import { getMe, loginSalawatAccount, logout as logoutApi, registerSalawatAccount } from "@/lib/_core/api";

const ADHAN_SETTINGS_KEY = "salawat.adhan.settings";
const ADHAN_AUDIO_URL = "https://upload.wikimedia.org/wikipedia/commons/b/b0/Beautiful_adhan.ogg";
const PRAYERS = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"] as const;
const PRAYER_LABELS: Record<(typeof PRAYERS)[number], string> = { Fajr: "الفجر", Dhuhr: "الظهر", Asr: "العصر", Maghrib: "المغرب", Isha: "العشاء" };

export default function ProfileScreen() {
  const [notifications, setNotifications] = useState(true);
  const [adhan, setAdhan] = useState(false);
  const [user, setUser] = useState<Auth.User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("register");
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [adhanByPrayer, setAdhanByPrayer] = useState<Record<string, boolean>>({ Fajr: true, Dhuhr: true, Asr: true, Maghrib: true, Isha: true });
  const adhanPlayer = useAudioPlayer(ADHAN_AUDIO_URL, { updateInterval: 500 });
  const adhanStatus = useAudioPlayerStatus(adhanPlayer);

  useEffect(() => {
    getMe().then((remoteUser) => {
      if (remoteUser) setUser({ ...remoteUser, lastSignedIn: new Date(remoteUser.lastSignedIn) });
      else Auth.getUserInfo().then(setUser).catch(() => undefined);
    }).catch(() => Auth.getUserInfo().then(setUser).catch(() => undefined));
  }, []);

  useEffect(() => {
    AsyncStorage.getItem(ADHAN_SETTINGS_KEY).then((value) => {
      if (!value) return;
      try {
        const saved = JSON.parse(value);
        if (saved && typeof saved === "object") setAdhanByPrayer((current) => ({ ...current, ...saved }));
      } catch {
        // Keep safe defaults when local settings are malformed.
      }
    }).catch(() => undefined);
    return () => adhanPlayer.remove();
  }, [adhanPlayer]);

  const updateAdhanPrayer = (prayer: string, enabled: boolean) => {
    setAdhan(true);
    setAdhanByPrayer((current) => {
      const next = { ...current, [prayer]: enabled };
      AsyncStorage.setItem(ADHAN_SETTINGS_KEY, JSON.stringify(next)).catch(() => undefined);
      return next;
    });
  };

  const submitAccount = async () => {
    setIsAuthLoading(true);
    setAuthError("");
    try {
      const remoteUser = authMode === "register"
        ? await registerSalawatAccount(authName, authEmail, authPassword)
        : await loginSalawatAccount(authEmail, authPassword);
      setUser({ ...remoteUser, lastSignedIn: new Date(remoteUser.lastSignedIn) });
      setAuthName("");
      setAuthEmail("");
      setAuthPassword("");
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : "Connexion impossible");
    } finally {
      setIsAuthLoading(false);
    }
  };

  const signOut = async () => {
    setIsAuthLoading(true);
    try {
      await logoutApi();
      await Auth.removeSessionToken();
      await Auth.clearUserInfo();
      setUser(null);
    } catch {
      // Keep the local account card usable if the network is unavailable.
    } finally {
      setIsAuthLoading(false);
    }
  };

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <PageHeader eyebrow="Votre espace" title="Profil & réglages" description="Personnalisez Salawat selon votre quotidien." />
        <View style={styles.profileCard}><SalawatMark size={54} /><View style={styles.profileCopy}><Text style={styles.profileName}>{user?.name ?? "Votre compte Salawat"}</Text><Text style={styles.profileDetail}>{user?.email ?? "Synchronisez vos préférences sur vos appareils"}</Text></View><Icon name={user ? "verified-user" : "person-outline"} size={22} color={SALAWAT_COLORS.goldSoft} /></View>
        <View style={styles.accountActions}>{user ? <><Text style={styles.accountStatus}>Compte Salawat connecté · e-mail et mot de passe</Text><Pressable style={styles.accountButtonSecondary} onPress={signOut} disabled={isAuthLoading}><Icon name="logout" size={17} color={SALAWAT_COLORS.emerald} /><Text style={styles.accountButtonSecondaryText}>{isAuthLoading ? "Déconnexion…" : "Se déconnecter"}</Text></Pressable></> : <View style={styles.authCard}><View style={styles.authModeRow}><Pressable onPress={() => setAuthMode("register")}><Text style={[styles.authModeText, authMode === "register" && styles.authModeTextSelected]}>Créer un compte</Text></Pressable><Pressable onPress={() => setAuthMode("login")}><Text style={[styles.authModeText, authMode === "login" && styles.authModeTextSelected]}>Se connecter</Text></Pressable></View>{authMode === "register" ? <TextInput value={authName} onChangeText={setAuthName} placeholder="Nom" placeholderTextColor={SALAWAT_COLORS.muted} style={styles.authInput} autoCapitalize="words" /> : null}<TextInput value={authEmail} onChangeText={setAuthEmail} placeholder="Adresse e-mail" placeholderTextColor={SALAWAT_COLORS.muted} style={styles.authInput} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} /><TextInput value={authPassword} onChangeText={setAuthPassword} placeholder="Mot de passe · 8 caractères minimum" placeholderTextColor={SALAWAT_COLORS.muted} style={styles.authInput} secureTextEntry /><Pressable style={styles.accountButton} onPress={submitAccount} disabled={isAuthLoading}><Icon name={authMode === "register" ? "person-add" : "login"} size={18} color={SALAWAT_COLORS.white} /><Text style={styles.accountButtonText}>{isAuthLoading ? "Patientez…" : authMode === "register" ? "Créer mon compte Salawat" : "Se connecter à Salawat"}</Text></Pressable>{authError ? <Text style={styles.authError}>{authError}</Text> : null}<Text style={styles.authNote}>Votre compte est indépendant de Manus. Les préférences peuvent être synchronisées avec Salawat.</Text></View>}</View>

        <Text style={styles.groupLabel}>LOCALISATION</Text>
        <Pressable style={styles.settingRow}><View style={[styles.settingIcon, { backgroundColor: SALAWAT_COLORS.emeraldSoft }]}><Icon name="location-on" size={19} color={SALAWAT_COLORS.emerald} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Ville actuelle</Text><Text style={styles.settingDetail}>{currentLocation.city}, {currentLocation.country}</Text></View><Icon name="chevron-right" size={20} color={SALAWAT_COLORS.muted} /></Pressable>
        <Pressable style={styles.settingRow}><View style={[styles.settingIcon, { backgroundColor: SALAWAT_COLORS.goldSoft }]}><Icon name="calculate" size={19} color={SALAWAT_COLORS.gold} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Méthode de calcul</Text><Text style={styles.settingDetail}>Muslim World League</Text></View><Icon name="chevron-right" size={20} color={SALAWAT_COLORS.muted} /></Pressable>
        <Pressable style={styles.settingRow}><View style={[styles.settingIcon, { backgroundColor: "#E8EFF2" }]}><Icon name="accessibility" size={19} color={SALAWAT_COLORS.blue} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>École juridique</Text><Text style={styles.settingDetail}>Standard · Asr à 16:19</Text></View><Icon name="chevron-right" size={20} color={SALAWAT_COLORS.muted} /></Pressable>

        <Text style={styles.groupLabel}>NOTIFICATIONS</Text>
        <View style={styles.settingRow}><View style={[styles.settingIcon, { backgroundColor: "#F1E8E6" }]}><Icon name="notifications-none" size={19} color="#A65849" /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Rappels de prière</Text><Text style={styles.settingDetail}>Recevoir une notification avant chaque prière</Text></View><Switch value={notifications} onValueChange={setNotifications} trackColor={{ false: "#CBD8D2", true: SALAWAT_COLORS.emeraldSoft }} thumbColor={notifications ? SALAWAT_COLORS.emerald : "#FFFFFF"} /></View>
        <View style={styles.settingRow}><View style={[styles.settingIcon, { backgroundColor: SALAWAT_COLORS.goldSoft }]}><Icon name="volume-up" size={19} color={SALAWAT_COLORS.gold} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Adhan sonore</Text><Text style={styles.settingDetail}>Choisissez les prières qui doivent utiliser le son</Text></View><Switch value={adhan} onValueChange={setAdhan} trackColor={{ false: "#CBD8D2", true: SALAWAT_COLORS.emeraldSoft }} thumbColor={adhan ? SALAWAT_COLORS.emerald : "#FFFFFF"} /></View>
        {adhan ? <View style={styles.adhanCard}><Text style={styles.adhanTitle}>Son de l’adhan par prière</Text>{PRAYERS.map((prayer) => <View key={prayer} style={styles.adhanRow}><View style={styles.adhanCopy}><Text style={styles.adhanPrayer}>{prayer}</Text><Text style={styles.adhanArabic}>{PRAYER_LABELS[prayer]}</Text></View><Pressable accessibilityRole="button" accessibilityLabel={`Écouter l’adhan de ${prayer}`} style={styles.previewButton} onPress={() => { if (adhanStatus.playing) adhanPlayer.pause(); else adhanPlayer.play(); }}><Icon name={adhanStatus.playing ? "pause" : "play-arrow"} size={18} color={SALAWAT_COLORS.emerald} /></Pressable><Switch value={Boolean(adhanByPrayer[prayer])} onValueChange={(value) => updateAdhanPrayer(prayer, value)} trackColor={{ false: "#CBD8D2", true: SALAWAT_COLORS.emeraldSoft }} thumbColor={adhanByPrayer[prayer] ? SALAWAT_COLORS.emerald : "#FFFFFF"} /></View>)}<Text style={styles.adhanNote}>معاينة من Wikimedia Commons بترخيص CC0. سيتم تفعيل التنبيه التلقائي بعد ربطه بمواعيد الصلاة المحلية الحقيقية.</Text></View> : null}

        <Text style={styles.groupLabel}>SOUTENIR SALAWAT</Text>
        <View style={styles.adCard}><View style={styles.adIcon}><Icon name="campaign" size={21} color={SALAWAT_COLORS.gold} /></View><View style={styles.settingCopy}><Text style={styles.adTitle}>Espace sponsorisé</Text><Text style={styles.adDetail}>Des annonces discrètes et respectueuses peuvent aider à financer les serveurs de Salawat.</Text></View><Text style={styles.adLabel}>PUBLICITÉ</Text></View>

        <Text style={styles.groupLabel}>MA COMMUNAUTÉ</Text>
        <Pressable style={styles.manageCard} onPress={() => router.push("/manage")}><View style={styles.manageIcon}><Icon name="admin-panel-settings" size={22} color={SALAWAT_COLORS.gold} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Gérer {managedMosque.name}</Text><Text style={styles.settingDetail}>Horaires, informations, équipe et annonces</Text></View><Icon name="chevron-right" size={20} color={SALAWAT_COLORS.muted} /></Pressable>

        <View style={styles.footer}><Text style={styles.footerBrand}>Salawat · v1.0</Text><Text style={styles.footerText}>Les horaires affichés sont personnalisables selon votre ville.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 18, paddingTop: 18, paddingBottom: 110, maxWidth: 700, width: "100%", alignSelf: "center" },
  profileCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: SALAWAT_COLORS.emerald, padding: 16, borderRadius: 22, marginBottom: 24 },
  profileCopy: { flex: 1 },
  profileName: { color: SALAWAT_COLORS.white, fontSize: 15, fontWeight: "900" },
  profileDetail: { color: "#BCE1D3", fontSize: 11, lineHeight: 16, marginTop: 4 },
  accountActions: { marginTop: -15, marginBottom: 22, paddingHorizontal: 3 },
  authCard: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 16, padding: 12, gap: 9 },
  authModeRow: { flexDirection: "row", gap: 18, marginBottom: 2 },
  authModeText: { color: SALAWAT_COLORS.muted, fontSize: 12, fontWeight: "800" },
  authModeTextSelected: { color: SALAWAT_COLORS.emerald },
  authInput: { height: 43, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 11, paddingHorizontal: 12, color: SALAWAT_COLORS.ink, fontSize: 12, backgroundColor: SALAWAT_COLORS.paper },
  authError: { color: "#A65849", fontSize: 11, lineHeight: 16 },
  authNote: { color: SALAWAT_COLORS.muted, fontSize: 10, lineHeight: 15 },
  accountStatus: { color: SALAWAT_COLORS.muted, fontSize: 10, marginBottom: 8 },
  accountButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: SALAWAT_COLORS.gold, borderRadius: 13, paddingVertical: 11, paddingHorizontal: 14 },
  accountButtonText: { color: SALAWAT_COLORS.white, fontSize: 12, fontWeight: "900" },
  accountButtonSecondary: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 13, paddingVertical: 9, paddingHorizontal: 14, backgroundColor: SALAWAT_COLORS.white },
  accountButtonSecondaryText: { color: SALAWAT_COLORS.emerald, fontSize: 11, fontWeight: "900" },
  groupLabel: { color: SALAWAT_COLORS.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.2, marginBottom: 9, marginTop: 5 },
  settingRow: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 16, padding: 12, flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 8 },
  settingIcon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  settingCopy: { flex: 1 },
  settingTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  settingDetail: { color: SALAWAT_COLORS.muted, fontSize: 11, lineHeight: 16, marginTop: 3 },
  manageCard: { backgroundColor: "#F4EFE3", borderRadius: 16, padding: 12, flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 8 },
  manageIcon: { width: 39, height: 39, borderRadius: 13, backgroundColor: SALAWAT_COLORS.goldSoft, alignItems: "center", justifyContent: "center" },
  footer: { alignItems: "center", paddingVertical: 25 },
  footerBrand: { color: SALAWAT_COLORS.emerald, fontSize: 12, fontWeight: "900" },
  footerText: { color: SALAWAT_COLORS.muted, fontSize: 10, marginTop: 5, textAlign: "center" },
  adhanCard: { backgroundColor: "#F4EFE3", borderRadius: 18, padding: 14, marginBottom: 16 },
  adhanTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900", marginBottom: 8 },
  adhanRow: { flexDirection: "row", alignItems: "center", gap: 9, paddingVertical: 8, borderTopWidth: 1, borderTopColor: "#E8DDC8" },
  adhanCopy: { flex: 1 },
  adhanPrayer: { color: SALAWAT_COLORS.ink, fontSize: 12, fontWeight: "800" },
  adhanArabic: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 2 },
  previewButton: { width: 32, height: 32, borderRadius: 10, backgroundColor: SALAWAT_COLORS.white, alignItems: "center", justifyContent: "center" },
  adhanNote: { color: SALAWAT_COLORS.muted, fontSize: 10, lineHeight: 15, marginTop: 8 },
  adCard: { flexDirection: "row", alignItems: "center", gap: 11, backgroundColor: "#F4EFE3", borderRadius: 17, padding: 13, marginBottom: 18 },
  adIcon: { width: 39, height: 39, borderRadius: 13, backgroundColor: SALAWAT_COLORS.goldSoft, alignItems: "center", justifyContent: "center" },
  adTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  adDetail: { color: SALAWAT_COLORS.muted, fontSize: 10, lineHeight: 15, marginTop: 3 },
  adLabel: { color: SALAWAT_COLORS.gold, fontSize: 8, fontWeight: "900", letterSpacing: 0.8 },
});
