import * as Location from "expo-location";
import { useEffect, useState } from "react";
import { AppState, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { SALAWAT_COLORS, currentLocation } from "@/constants/salawat";
import { Icon, PageHeader, Pill } from "@/components/salawat-ui";
import { ScreenContainer } from "@/components/screen-container";

const KAABA = { latitude: 21.4225, longitude: 39.8262 };
const DEFAULT_QIBLA_BEARING = 118;

function normalizeHeading(value: number) {
  return ((value % 360) + 360) % 360;
}

function calculateBearing(latitude: number, longitude: number) {
  const latitude1 = (latitude * Math.PI) / 180;
  const latitude2 = (KAABA.latitude * Math.PI) / 180;
  const longitudeDelta = ((KAABA.longitude - longitude) * Math.PI) / 180;
  const y = Math.sin(longitudeDelta) * Math.cos(latitude2);
  const x = Math.cos(latitude1) * Math.sin(latitude2) - Math.sin(latitude1) * Math.cos(latitude2) * Math.cos(longitudeDelta);
  return (Math.round((((Math.atan2(y, x) * 180) / Math.PI + 360) % 360) * 10) / 10);
}

export default function QiblaScreen() {
  const [calibrated, setCalibrated] = useState(false);
  const [mode, setMode] = useState("Boussole");
  const [qiblaBearing, setQiblaBearing] = useState(DEFAULT_QIBLA_BEARING);
  const [heading, setHeading] = useState<number | null>(null);
  const [locationReady, setLocationReady] = useState(false);
  const [locationError, setLocationError] = useState(false);
  const [compassError, setCompassError] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    let mounted = true;
    let headingSubscription: Location.LocationSubscription | undefined;

    const initializeCompass = async () => {
      try {
        setLocationError(false);
        setCompassError(false);
        if (!(await Location.hasServicesEnabledAsync())) {
          if (mounted) setLocationError(true);
          return;
        }
        const permission = await Location.requestForegroundPermissionsAsync();
        if (permission.status !== "granted") {
          if (mounted) setLocationError(true);
          return;
        }

        const lastKnown = await Location.getLastKnownPositionAsync();
        if (mounted && lastKnown) {
          setQiblaBearing(calculateBearing(lastKnown.coords.latitude, lastKnown.coords.longitude));
          setLocationReady(true);
        }

        const position = await Promise.race([
          Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }),
          new Promise<null>((resolve) => setTimeout(() => resolve(null), 12000)),
        ]);
        if (!position) {
          if (mounted && !lastKnown) setLocationError(true);
        } else if (mounted) {
          setQiblaBearing(calculateBearing(position.coords.latitude, position.coords.longitude));
          setLocationReady(true);
        }

        if (Platform.OS !== "web") {
          let receivedHeading = false;
          try {
            headingSubscription = await Location.watchHeadingAsync((nextHeading) => {
              if (!mounted) return;
              const nextValue = nextHeading.trueHeading >= 0 ? nextHeading.trueHeading : nextHeading.magHeading;
              if (nextValue < 0 || !Number.isFinite(nextValue)) {
                setCompassError(true);
                setHeading(null);
                return;
              }
              setCompassError(false);
              receivedHeading = true;
              setHeading(normalizeHeading(nextValue));
              setCalibrated(nextHeading.accuracy >= 2);
            });
            setTimeout(() => {
              if (mounted && !receivedHeading) setCompassError(true);
            }, 5000);
          } catch {
            if (mounted) setCompassError(true);
          }
        }
      } catch {
        if (mounted) setLocationError(true);
      }
    };

    initializeCompass();
    const appStateSubscription = AppState.addEventListener("change", (nextState) => {
      if (nextState === "active") setRefreshKey((value) => value + 1);
    });
    return () => {
      mounted = false;
      appStateSubscription.remove();
      headingSubscription?.remove();
    };
  }, [refreshKey]);

  const needleRotation = heading === null ? qiblaBearing : qiblaBearing - heading;
  const accuracyLabel = locationError ? "Position indisponible" : compassError ? "Mode fixe" : calibrated ? "Précise" : locationReady ? "À calibrer" : "Recherche…";
  const accuracyColor = locationError || compassError ? "#D78665" : calibrated ? "#7DE0B3" : SALAWAT_COLORS.gold;

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <PageHeader eyebrow="Orientation" title="La Qibla" description={locationReady ? "Direction calculée depuis votre position GPS." : `Direction de la Kaaba depuis ${currentLocation.city}.`} />

        <View style={styles.modeRow}>
          <Pill selected={mode === "Boussole"} onPress={() => setMode("Boussole")}>Boussole</Pill>
          <Pill selected={mode === "Carte"} onPress={() => setMode("Carte")}>Carte</Pill>
        </View>

        <View style={styles.compassCard}>
          <View style={styles.compassHeader}><Text style={styles.compassLabel}>DIRECTION DE LA QIBLA</Text><View style={styles.accuracy}><View style={[styles.accuracyDot, { backgroundColor: accuracyColor }]} /><Text style={styles.accuracyText}>{accuracyLabel}</Text></View></View>
          <View style={styles.compass}>
            <View style={styles.ringOuter} />
            <View style={styles.ringInner} />
            <Text style={[styles.cardinal, styles.north]}>N</Text><Text style={[styles.cardinal, styles.east]}>E</Text><Text style={[styles.cardinal, styles.south]}>S</Text><Text style={[styles.cardinal, styles.west]}>O</Text>
            <View style={[styles.needle, { transform: [{ rotate: `${needleRotation}deg` }] }]}><View style={styles.needleGold} /><View style={styles.needleStem} /></View>
            <View style={styles.kaaba}><Icon name="mosque" size={26} color={SALAWAT_COLORS.white} /></View>
          </View>
          <View style={styles.degreeRow}><Text style={styles.degreeValue}>{Math.round(qiblaBearing)}°</Text><Text style={styles.degreeLabel}>par rapport au nord · {mode === "Carte" ? "direction fixe" : heading === null ? "orientation fixe" : "cap en direct"}</Text></View>
          <Pressable accessibilityRole="button" accessibilityLabel="Actualiser la position et recalibrer la boussole" style={styles.calibrateButton} onPress={() => { setCalibrated(false); setLocationError(false); setCompassError(false); setRefreshKey((value) => value + 1); }}><Icon name={calibrated ? "check-circle" : "sync"} size={18} color={SALAWAT_COLORS.white} /><Text style={styles.calibrateText}>{compassError ? "Réessayer la boussole" : calibrated ? "Actualiser la boussole" : "Bougez le téléphone en 8"}</Text></Pressable>
        </View>

        {locationError ? <View style={styles.warningCard}><Icon name="location-off" size={20} color={SALAWAT_COLORS.gold} /><View style={styles.warningCopy}><Text style={styles.warningTitle}>Localisation nécessaire</Text><Text style={styles.warningDetail}>Autorisez la localisation puis appuyez sur le bouton pour calculer votre angle réel.</Text></View></View> : null}
        {compassError ? <View style={styles.warningCard}><Icon name="explore-off" size={20} color={SALAWAT_COLORS.gold} /><View style={styles.warningCopy}><Text style={styles.warningTitle}>Boussole indisponible</Text><Text style={styles.warningDetail}>La direction calculée reste visible, mais le cap en direct n’est pas disponible sur ce téléphone. Éloignez-le du métal et réessayez.</Text></View></View> : null}

        <View style={styles.infoCard}><View style={styles.infoIcon}><Icon name="lightbulb-outline" size={20} color={SALAWAT_COLORS.gold} /></View><View style={styles.infoCopy}><Text style={styles.infoTitle}>Pour une meilleure précision</Text><Text style={styles.infoDetail}>Éloignez votre téléphone des objets métalliques et faites un mouvement en forme de 8.</Text></View></View>

        <View style={styles.placeCard}><Icon name="location-on" size={18} color={SALAWAT_COLORS.emerald} /><View style={styles.placeCopy}><Text style={styles.placeTitle}>{currentLocation.city}, {currentLocation.country}</Text><Text style={styles.placeDetail}>{locationReady ? "Angle calculé selon votre position GPS" : "Position de référence · activez la localisation pour plus de précision"}</Text></View><Icon name="my-location" size={18} color={locationReady ? SALAWAT_COLORS.emerald : SALAWAT_COLORS.muted} /></View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 18, paddingTop: 18, paddingBottom: 110, maxWidth: 620, width: "100%", alignSelf: "center" },
  modeRow: { flexDirection: "row", gap: 8, marginBottom: 16 },
  compassCard: { backgroundColor: SALAWAT_COLORS.emerald, borderRadius: 26, padding: 18, alignItems: "center", overflow: "hidden" },
  compassHeader: { flexDirection: "row", justifyContent: "space-between", width: "100%", alignItems: "center" },
  compassLabel: { color: "#A8D7C6", fontSize: 10, letterSpacing: 1.1, fontWeight: "900" },
  accuracy: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "rgba(255,255,255,0.13)", borderRadius: 20, paddingHorizontal: 9, paddingVertical: 6 },
  accuracyDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: SALAWAT_COLORS.gold },
  accuracyText: { color: SALAWAT_COLORS.goldSoft, fontSize: 10, fontWeight: "800" },
  compass: { width: 270, height: 270, borderRadius: 135, borderWidth: 1, borderColor: "rgba(255,255,255,0.2)", marginVertical: 26, alignItems: "center", justifyContent: "center", position: "relative" },
  ringOuter: { position: "absolute", width: 226, height: 226, borderRadius: 113, borderWidth: 1, borderColor: "rgba(255,255,255,0.18)" },
  ringInner: { position: "absolute", width: 172, height: 172, borderRadius: 86, borderWidth: 1, borderColor: "rgba(255,255,255,0.14)" },
  cardinal: { position: "absolute", color: "#BCE1D3", fontSize: 13, fontWeight: "900" },
  north: { top: 14 }, east: { right: 18 }, south: { bottom: 14 }, west: { left: 18 },
  needle: { width: 3, height: 115, position: "absolute", alignItems: "center", transform: [{ rotate: "118deg" }] },
  needleGold: { height: 58, width: 4, backgroundColor: SALAWAT_COLORS.gold },
  needleStem: { height: 57, width: 4, backgroundColor: "rgba(255,255,255,0.4)" },
  kaaba: { width: 56, height: 56, borderRadius: 20, backgroundColor: SALAWAT_COLORS.gold, alignItems: "center", justifyContent: "center", borderWidth: 4, borderColor: "#EFD38E" },
  degreeRow: { alignItems: "center" },
  degreeValue: { color: SALAWAT_COLORS.white, fontSize: 33, fontWeight: "900" },
  degreeLabel: { color: "#A8D7C6", fontSize: 11, marginTop: 3 },
  calibrateButton: { marginTop: 18, width: "100%", height: 48, borderRadius: 15, backgroundColor: "rgba(255,255,255,0.14)", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  calibrateText: { color: SALAWAT_COLORS.white, fontSize: 13, fontWeight: "900" },
  infoCard: { backgroundColor: "#F4EFE3", borderRadius: 18, padding: 14, flexDirection: "row", gap: 11, marginTop: 15 },
  infoIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: SALAWAT_COLORS.goldSoft, alignItems: "center", justifyContent: "center" },
  infoCopy: { flex: 1 },
  infoTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  infoDetail: { color: SALAWAT_COLORS.muted, fontSize: 11, lineHeight: 17, marginTop: 3 },
  warningCard: { backgroundColor: "#FFF3E6", borderRadius: 18, padding: 14, flexDirection: "row", gap: 11, marginTop: 15, alignItems: "flex-start" },
  warningCopy: { flex: 1 },
  warningTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  warningDetail: { color: SALAWAT_COLORS.muted, fontSize: 11, lineHeight: 17, marginTop: 3 },
  placeCard: { marginTop: 11, backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 16, padding: 14, flexDirection: "row", alignItems: "center", gap: 10 },
  placeCopy: { flex: 1 },
  placeTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  placeDetail: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 3 },
});
