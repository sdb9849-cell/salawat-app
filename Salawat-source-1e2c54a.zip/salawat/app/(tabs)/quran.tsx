import { useEffect, useMemo, useState } from "react";
import { useAudioPlayer, useAudioPlayerStatus } from "@/lib/audio-player";
import { Directory, File, Paths } from "expo-file-system";
import { ActivityIndicator, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { SALAWAT_COLORS } from "@/constants/salawat";
import { Icon, SalawatMark } from "@/components/salawat-ui";
import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";

const BOOKMARKS_STORAGE_KEY = "salawat.quran.bookmarks";
const LAST_READ_STORAGE_KEY = "salawat.quran.last-read";
const RECITER_STORAGE_KEY = "salawat.quran.reciter";
const SURAH_LIST_CACHE_KEY = "salawat.quran.surah-list";
const SURAH_CACHE_PREFIX = "salawat.quran.surah.simple-v2.";
const AUDIO_CACHE_PREFIX = "salawat.quran.audio.";
const AUDIO_DIRECTORY = Platform.OS === "web" ? null : new Directory(Paths.document, "quran-audio");
const DEFAULT_RECITER = "ar.alafasy";

type QuranReciter = { identifier: string; name: string; englishName: string; style: string };
type QuranSurahSummary = { number: number; name: string; englishName: string; englishNameTranslation: string; numberOfAyahs: number; revelationType: string };
type QuranSurahContent = { number: number; name: string; englishName: string; numberOfAyahs: number; source: string; verses: { number: number; arabic: string; translation: string; footnotes: string }[] };

export default function QuranScreen() {
  const [search, setSearch] = useState("");
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [bookmarked, setBookmarked] = useState<string[]>([]);
  const [lastReadSurah, setLastReadSurah] = useState(1);
  const [selectedReciter, setSelectedReciter] = useState(DEFAULT_RECITER);
  const [cachedSurahs, setCachedSurahs] = useState<QuranSurahSummary[]>([]);
  const [storageReady, setStorageReady] = useState(false);
  const surahsQuery = trpc.quran.surahs.useQuery();
  const recitersQuery = trpc.quran.reciters.useQuery();
  useEffect(() => {
    AsyncStorage.multiGet([BOOKMARKS_STORAGE_KEY, LAST_READ_STORAGE_KEY, RECITER_STORAGE_KEY, SURAH_LIST_CACHE_KEY]).then(([bookmarksEntry, lastReadEntry, reciterEntry, surahListEntry]) => {
      try {
        const storedBookmarks = bookmarksEntry[1] ? JSON.parse(bookmarksEntry[1]) : [];
        if (Array.isArray(storedBookmarks)) setBookmarked(storedBookmarks.filter((item): item is string => typeof item === "string"));
        const storedLastRead = lastReadEntry[1] ? Number(lastReadEntry[1]) : 1;
        if (Number.isInteger(storedLastRead) && storedLastRead >= 1 && storedLastRead <= 114) setLastReadSurah(storedLastRead);
        if (reciterEntry[1]) setSelectedReciter(reciterEntry[1]);
        if (surahListEntry[1]) {
          const storedSurahs = JSON.parse(surahListEntry[1]);
          if (Array.isArray(storedSurahs)) setCachedSurahs(storedSurahs);
        }
      } catch {
        // Ignore malformed local state and keep the safe defaults.
      } finally {
        setStorageReady(true);
      }
    }).catch(() => setStorageReady(true));
  }, []);
  useEffect(() => {
    if (!surahsQuery.data?.length) return;
    AsyncStorage.setItem(SURAH_LIST_CACHE_KEY, JSON.stringify(surahsQuery.data)).catch(() => undefined);
  }, [surahsQuery.data]);
  useEffect(() => {
    if (storageReady) {
      AsyncStorage.setItem(BOOKMARKS_STORAGE_KEY, JSON.stringify(bookmarked)).catch(() => undefined);
    }
  }, [bookmarked, storageReady]);
  useEffect(() => {
    if (storageReady) AsyncStorage.setItem(RECITER_STORAGE_KEY, selectedReciter).catch(() => undefined);
  }, [selectedReciter, storageReady]);
  const openSurah = (number: number) => {
    setLastReadSurah(number);
    setSelectedNumber(number);
    AsyncStorage.setItem(LAST_READ_STORAGE_KEY, String(number)).catch(() => undefined);
  };
  const filteredSurahs = useMemo(() => {
    const normalized = search.trim().toLowerCase();
    return (surahsQuery.data ?? cachedSurahs).filter((surah) => !normalized || `${surah.number} ${surah.name} ${surah.englishName} ${surah.englishNameTranslation}`.toLowerCase().includes(normalized));
  }, [cachedSurahs, search, surahsQuery.data]);

  if (selectedNumber !== null) {
    return <QuranReader number={selectedNumber} reciter={selectedReciter} onBack={() => setSelectedNumber(null)} bookmarked={bookmarked} setBookmarked={setBookmarked} />;
  }

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.quranHero}><View style={styles.heroBrand}><SalawatMark size={43} /><View><Text style={styles.heroKicker}>LECTURE & MÉDITATION</Text><Text style={styles.heroTitle}>Le Quran</Text></View></View><Text style={styles.heroArabic}>القرآن الكريم</Text><Text style={styles.heroDescription}>Lisez, réfléchissez et avancez à votre rythme.</Text></View>
        <View style={styles.searchBox}><Icon name="search" size={20} color={SALAWAT_COLORS.muted} /><TextInput value={search} onChangeText={setSearch} placeholder="Rechercher une sourate" placeholderTextColor={SALAWAT_COLORS.muted} style={styles.searchInput} /></View>
        <Pressable style={styles.continueCard} onPress={() => openSurah(lastReadSurah)}><View style={styles.continueIcon}><Icon name="menu-book" size={22} color={SALAWAT_COLORS.gold} /></View><View style={styles.continueCopy}><Text style={styles.continueKicker}>REPRENDRE LA LECTURE</Text><Text style={styles.continueTitle}>Sourate {lastReadSurah} · verset 1</Text><View style={styles.progressTrack}><View style={styles.progressFill} /></View></View><Icon name="play-arrow" size={25} color={SALAWAT_COLORS.emerald} /></Pressable>
        <View style={styles.reciterCard}><View style={styles.reciterHeader}><View><Text style={styles.reciterKicker}>RÉCITATEUR</Text><Text style={styles.reciterTitle}>Choisissez votre voix</Text></View><Icon name="record-voice-over" size={22} color={SALAWAT_COLORS.gold} /></View><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.reciterList}>{(recitersQuery.data ?? []).map((reciter: QuranReciter) => <Pressable key={reciter.identifier} onPress={() => setSelectedReciter(reciter.identifier)} style={[styles.reciterPill, selectedReciter === reciter.identifier && styles.reciterPillSelected]}><Text style={[styles.reciterName, selectedReciter === reciter.identifier && styles.reciterNameSelected]}>{reciter.englishName}</Text></Pressable>)}</ScrollView><Text style={styles.reciterSelected}>{recitersQuery.data?.find((reciter: QuranReciter) => reciter.identifier === selectedReciter)?.name ?? "Mishary Rashid Alafasy"}</Text></View>
        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>Les sourates</Text><Text style={styles.sectionMeta}>{cachedSurahs.length || surahsQuery.data?.length || 114} sourates · {surahsQuery.isError ? "hors ligne" : "disponibles"}</Text></View>
        {surahsQuery.isLoading ? <View style={styles.loading}><ActivityIndicator color={SALAWAT_COLORS.emerald} /><Text style={styles.loadingText}>Chargement du Quran…</Text></View> : null}
        {surahsQuery.isError && cachedSurahs.length === 0 ? <View style={styles.errorCard}><Icon name="cloud-off" size={22} color={SALAWAT_COLORS.gold} /><Text style={styles.errorTitle}>Connexion nécessaire</Text><Text style={styles.errorDetail}>Ouvrez une sourate une première fois en ligne pour la conserver sur cet appareil.</Text><Pressable onPress={() => surahsQuery.refetch()}><Text style={styles.retryText}>Réessayer</Text></Pressable></View> : null}
        {filteredSurahs.map((surah) => <Pressable key={surah.number} onPress={() => openSurah(surah.number)} style={({ pressed }) => [styles.surahRow, pressed && styles.pressed]}><View style={styles.surahNumber}><Text style={styles.surahNumberText}>{surah.number}</Text></View><View style={styles.surahCopy}><Text style={styles.surahLatin}>{surah.englishName}</Text><Text style={styles.surahTranslation}>{surah.englishNameTranslation} · {surah.numberOfAyahs} versets</Text></View><Text style={styles.surahArabic}>{surah.name}</Text><Icon name="chevron-right" size={19} color={SALAWAT_COLORS.muted} /></Pressable>)}
        <Text style={styles.sourceNote}>Texte arabe : Al Quran Cloud · Traduction française : QuranEnc, Rachid Maach, version 1.0.3.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

function formatAudioTime(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return "00:00";
  const minutes = Math.floor(seconds / 60);
  const remaining = Math.floor(seconds % 60);
  return `${String(minutes).padStart(2, "0")}:${String(remaining).padStart(2, "0")}`;
}

function QuranReader({ number, reciter, onBack, bookmarked, setBookmarked }: { number: number; reciter: string; onBack: () => void; bookmarked: string[]; setBookmarked: (value: string[]) => void }) {
  const query = trpc.quran.surah.useQuery({ number });
  const [cachedSurah, setCachedSurah] = useState<QuranSurahContent | null>(null);
  const [localAudioUri, setLocalAudioUri] = useState<string | null>(null);
  const [isDownloadingAudio, setIsDownloadingAudio] = useState(false);
  const surah = query.data ?? cachedSurah;
  const audioUrl = `https://cdn.islamic.network/quran/audio-surah/128/${reciter}/${number}.mp3`;
  const audioSource = localAudioUri ?? audioUrl;
  const player = useAudioPlayer(audioSource, { updateInterval: 500 });
  const audioStatus = useAudioPlayerStatus(player);

  useEffect(() => {
    AsyncStorage.getItem(`${SURAH_CACHE_PREFIX}${number}`).then((value) => {
      if (!value) return;
      try {
        setCachedSurah(JSON.parse(value) as QuranSurahContent);
      } catch {
        // Ignore malformed cache and keep the network state.
      }
    }).catch(() => undefined);
  }, [number]);

  useEffect(() => {
    if (!AUDIO_DIRECTORY) return;
    const audioFile = new File(AUDIO_DIRECTORY, `${reciter}-${number}.mp3`);
    AsyncStorage.getItem(`${AUDIO_CACHE_PREFIX}${reciter}.${number}`).then((storedUri) => {
      if (storedUri && audioFile.exists) setLocalAudioUri(storedUri);
    }).catch(() => undefined);
  }, [number, reciter]);

  useEffect(() => {
    if (query.data) AsyncStorage.setItem(`${SURAH_CACHE_PREFIX}${number}`, JSON.stringify(query.data)).catch(() => undefined);
  }, [number, query.data]);

  useEffect(() => () => {
    player.pause();
    player.remove();
  }, [player]);

  useEffect(() => {
    player.replace(audioUrl);
    player.pause();
  }, [audioUrl, player]);

  const toggleBookmark = (verseNumber: number) => {
    const key = `${number}:${verseNumber}`;
    setBookmarked(bookmarked.includes(key) ? bookmarked.filter((item) => item !== key) : [...bookmarked, key]);
  };

  const toggleAudio = () => {
    if (audioStatus.playing) player.pause();
    else player.play();
  };

  const downloadAudio = async () => {
    if (!AUDIO_DIRECTORY) return;
    setIsDownloadingAudio(true);
    try {
      AUDIO_DIRECTORY.create({ idempotent: true, intermediates: true });
      const audioFile = await File.downloadFileAsync(audioUrl, new File(AUDIO_DIRECTORY, `${reciter}-${number}.mp3`), { idempotent: true });
      setLocalAudioUri(audioFile.uri);
      await AsyncStorage.setItem(`${AUDIO_CACHE_PREFIX}${reciter}.${number}`, audioFile.uri);
    } catch {
      // Keep online playback available when the device cannot save the file.
    } finally {
      setIsDownloadingAudio(false);
    }
  };

  const removeDownloadedAudio = () => {
    if (!AUDIO_DIRECTORY) return;
    try {
      const audioFile = new File(AUDIO_DIRECTORY, `${reciter}-${number}.mp3`);
      if (audioFile.exists) audioFile.delete();
    } catch {
      // The file may already have been removed by the operating system.
    }
    setLocalAudioUri(null);
    AsyncStorage.removeItem(`${AUDIO_CACHE_PREFIX}${reciter}.${number}`).catch(() => undefined);
  };

  const progress = audioStatus.duration > 0 ? Math.min(1, audioStatus.currentTime / audioStatus.duration) : 0;

  return <ScreenContainer><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}><View style={styles.readerTop}><Pressable onPress={onBack} style={styles.backButton}><Icon name="arrow-back" size={19} color={SALAWAT_COLORS.emerald} /></Pressable><Text style={styles.backText}>Toutes les sourates</Text><View style={{ flex: 1 }} /><Pressable style={styles.readerAction} onPress={() => { player.pause(); }}><Icon name="stop" size={19} color={SALAWAT_COLORS.emerald} /></Pressable></View>{query.isLoading && !cachedSurah ? <View style={styles.loading}><ActivityIndicator color={SALAWAT_COLORS.emerald} /><Text style={styles.loadingText}>Ouverture de la sourate…</Text></View> : null}{query.isError && !cachedSurah ? <View style={styles.errorCard}><Icon name="cloud-off" size={22} color={SALAWAT_COLORS.gold} /><Text style={styles.errorTitle}>Lecture indisponible</Text><Text style={styles.errorDetail}>هذه السورة غير محفوظة بعد. افتحها مرة واحدة أثناء الاتصال بالإنترنت.</Text><Pressable onPress={() => query.refetch()}><Text style={styles.retryText}>Réessayer</Text></Pressable></View> : null}{surah ? <><Text style={styles.offlineBadge}>{query.isError ? "Lecture hors ligne · texte enregistré" : "Texte enregistré automatiquement pour une prochaine lecture hors ligne"}</Text><View style={styles.surahHeader}><Text style={styles.surahHeaderKicker}>SOURATE {surah.number}</Text><Text style={styles.surahHeaderTitle}>{surah.englishName}</Text><Text style={styles.surahHeaderArabic}>{surah.name}</Text><Text style={styles.surahHeaderMeta}>{surah.numberOfAyahs} versets</Text></View><View style={styles.audioCard}><View style={styles.audioTop}><View style={styles.audioIcon}><Icon name={audioStatus.playing ? "pause" : "play-arrow"} size={22} color={SALAWAT_COLORS.emerald} /></View><View style={styles.audioCopy}><Text style={styles.audioTitle}>{audioStatus.isBuffering ? "Préparation de la récitation…" : audioStatus.playing ? "Récitation en cours" : localAudioUri ? "Récitation hors ligne" : "Écouter la sourate"}</Text><Text style={styles.audioDetail}>{reciter} · {localAudioUri ? "enregistrée sur cet appareil" : "audio en ligne"}</Text></View><Pressable accessibilityRole="button" accessibilityLabel={audioStatus.playing ? "Mettre en pause" : "Écouter la sourate"} style={styles.audioPlayButton} onPress={toggleAudio}><Icon name={audioStatus.playing ? "pause" : "play-arrow"} size={23} color={SALAWAT_COLORS.white} /></Pressable></View><View style={styles.audioTrack}><View style={[styles.audioProgress, { width: `${progress * 100}%` }]} /></View><View style={styles.audioTimes}><Text style={styles.audioTime}>{formatAudioTime(audioStatus.currentTime)}</Text><Text style={styles.audioTime}>{formatAudioTime(audioStatus.duration)}</Text></View><Text style={styles.audioSource}>Récitation fournie par Islamic Network · {localAudioUri ? "disponible sans connexion." : "une connexion est nécessaire."}</Text><Pressable accessibilityRole="button" style={styles.downloadAudioButton} onPress={localAudioUri ? removeDownloadedAudio : downloadAudio} disabled={isDownloadingAudio}><Icon name={isDownloadingAudio ? "hourglass-top" : localAudioUri ? "delete-outline" : "download"} size={18} color={SALAWAT_COLORS.emerald} /><Text style={styles.downloadAudioText}>{isDownloadingAudio ? "Téléchargement…" : localAudioUri ? "Supprimer la copie hors ligne" : "Télécharger pour écouter hors ligne"}</Text></Pressable></View><View style={styles.bismillah}><Text style={styles.bismillahText}>بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ</Text></View>{surah.verses.map((verse) => { const key = `${number}:${verse.number}`; return <View key={verse.number} style={styles.verseCard}><View style={styles.verseTop}><View style={styles.verseNumber}><Text style={styles.verseNumberText}>{verse.number}</Text></View><Pressable onPress={() => toggleBookmark(verse.number)}><Icon name={bookmarked.includes(key) ? "bookmark" : "bookmark-border"} size={20} color={bookmarked.includes(key) ? SALAWAT_COLORS.gold : SALAWAT_COLORS.muted} /></Pressable></View><Text style={styles.arabicText}>{verse.arabic}</Text><Text style={styles.translationText}>{verse.translation}</Text></View>; })}<Text style={styles.sourceNote}>{surah.source}. Les traductions sont affichées sans modification.</Text></> : null}</ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 18, paddingTop: 18, paddingBottom: 110, maxWidth: 760, width: "100%", alignSelf: "center" },
  quranHero: { backgroundColor: SALAWAT_COLORS.emerald, borderRadius: 24, padding: 19, overflow: "hidden", marginBottom: 14 },
  heroBrand: { flexDirection: "row", alignItems: "center", gap: 11 },
  heroKicker: { color: "#A8D7C6", fontSize: 10, letterSpacing: 1.2, fontWeight: "900" },
  heroTitle: { color: SALAWAT_COLORS.white, fontSize: 27, fontWeight: "900", marginTop: 3 },
  heroArabic: { color: SALAWAT_COLORS.goldSoft, fontSize: 25, lineHeight: 40, textAlign: "right", writingDirection: "rtl", includeFontPadding: true, marginTop: -18, fontWeight: "400" },
  heroDescription: { color: "#BCE1D3", fontSize: 12, marginTop: 18 },
  searchBox: { height: 52, borderRadius: 16, borderWidth: 1, borderColor: SALAWAT_COLORS.line, backgroundColor: SALAWAT_COLORS.white, flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 14, marginBottom: 12 },
  searchInput: { flex: 1, color: SALAWAT_COLORS.ink, fontSize: 13 },
  continueCard: { backgroundColor: "#F4EFE3", borderRadius: 18, padding: 13, flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 24 },
  continueIcon: { width: 40, height: 40, borderRadius: 13, backgroundColor: SALAWAT_COLORS.goldSoft, alignItems: "center", justifyContent: "center" },
  continueCopy: { flex: 1 },
  continueKicker: { color: SALAWAT_COLORS.gold, fontSize: 9, letterSpacing: 1, fontWeight: "900" },
  continueTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900", marginTop: 3 },
  progressTrack: { height: 4, borderRadius: 2, backgroundColor: "#E6D9BC", marginTop: 8, overflow: "hidden" },
  progressFill: { height: "100%", width: "18%", backgroundColor: SALAWAT_COLORS.gold },
  reciterCard: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 18, padding: 14, marginBottom: 24 },
  reciterHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  reciterKicker: { color: SALAWAT_COLORS.gold, fontSize: 9, letterSpacing: 1.1, fontWeight: "900" },
  reciterTitle: { color: SALAWAT_COLORS.ink, fontSize: 14, fontWeight: "900", marginTop: 4 },
  reciterList: { gap: 8, paddingTop: 13, paddingBottom: 8 },
  reciterPill: { borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 8, backgroundColor: SALAWAT_COLORS.paper },
  reciterPillSelected: { backgroundColor: SALAWAT_COLORS.emerald, borderColor: SALAWAT_COLORS.emerald },
  reciterName: { color: SALAWAT_COLORS.muted, fontSize: 11, fontWeight: "800" },
  reciterNameSelected: { color: SALAWAT_COLORS.white },
  reciterSelected: { color: SALAWAT_COLORS.muted, fontSize: 11, textAlign: "right" },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 11 },
  sectionTitle: { color: SALAWAT_COLORS.ink, fontSize: 18, fontWeight: "900" },
  sectionMeta: { color: SALAWAT_COLORS.muted, fontSize: 11 },
  surahRow: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 16, padding: 12, flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 8 },
  surahNumber: { width: 34, height: 34, borderRadius: 12, backgroundColor: SALAWAT_COLORS.emeraldSoft, alignItems: "center", justifyContent: "center" },
  surahNumberText: { color: SALAWAT_COLORS.emerald, fontSize: 12, fontWeight: "900" },
  surahCopy: { flex: 1 },
  surahLatin: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  surahTranslation: { color: SALAWAT_COLORS.muted, fontSize: 10, marginTop: 3 },
  surahArabic: { color: SALAWAT_COLORS.emerald, fontSize: 18, lineHeight: 30, textAlign: "right", writingDirection: "rtl", includeFontPadding: true, fontWeight: "400" },
  loading: { alignItems: "center", padding: 35, gap: 10 },
  loadingText: { color: SALAWAT_COLORS.muted, fontSize: 12 },
  errorCard: { alignItems: "center", backgroundColor: "#F4EFE3", borderRadius: 18, padding: 24, marginBottom: 15 },
  errorTitle: { color: SALAWAT_COLORS.ink, fontSize: 15, fontWeight: "900", marginTop: 8 },
  errorDetail: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 4, textAlign: "center" },
  retryText: { color: SALAWAT_COLORS.emerald, fontSize: 12, fontWeight: "900", marginTop: 12 },
  sourceNote: { color: SALAWAT_COLORS.muted, fontSize: 10, lineHeight: 15, textAlign: "center", marginTop: 18, marginBottom: 10 },
  pressed: { opacity: 0.78 },
  readerTop: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 19 },
  backButton: { width: 36, height: 36, borderRadius: 12, backgroundColor: SALAWAT_COLORS.emeraldSoft, alignItems: "center", justifyContent: "center" },
  backText: { color: SALAWAT_COLORS.muted, fontSize: 12, fontWeight: "800" },
  readerAction: { width: 36, height: 36, borderRadius: 12, backgroundColor: SALAWAT_COLORS.emeraldSoft, alignItems: "center", justifyContent: "center" },
  audioCard: { backgroundColor: "#EEF6F2", borderRadius: 18, padding: 14, marginTop: 12, marginBottom: 4 },
  audioTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  audioIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: SALAWAT_COLORS.white, alignItems: "center", justifyContent: "center" },
  audioCopy: { flex: 1 },
  audioTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  audioDetail: { color: SALAWAT_COLORS.muted, fontSize: 10, marginTop: 3 },
  audioPlayButton: { width: 40, height: 40, borderRadius: 14, backgroundColor: SALAWAT_COLORS.emerald, alignItems: "center", justifyContent: "center" },
  audioTrack: { height: 5, borderRadius: 3, backgroundColor: "#CFE3D9", marginTop: 14, overflow: "hidden" },
  audioProgress: { height: "100%", borderRadius: 3, backgroundColor: SALAWAT_COLORS.gold },
  audioTimes: { flexDirection: "row", justifyContent: "space-between", marginTop: 5 },
  audioTime: { color: SALAWAT_COLORS.muted, fontSize: 10 },
  audioSource: { color: SALAWAT_COLORS.muted, fontSize: 9, lineHeight: 13, marginTop: 9 },
  downloadAudioButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, backgroundColor: SALAWAT_COLORS.white, borderRadius: 12, paddingVertical: 9, paddingHorizontal: 10, marginTop: 11 },
  downloadAudioText: { color: SALAWAT_COLORS.emerald, fontSize: 10, fontWeight: "900" },
  offlineBadge: { color: SALAWAT_COLORS.emerald, backgroundColor: SALAWAT_COLORS.emeraldSoft, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7, fontSize: 10, lineHeight: 14, marginBottom: 10 },
  surahHeader: { backgroundColor: SALAWAT_COLORS.emerald, borderRadius: 22, padding: 20, alignItems: "center" },
  surahHeaderKicker: { color: "#A8D7C6", fontSize: 10, letterSpacing: 1.2, fontWeight: "900" },
  surahHeaderTitle: { color: SALAWAT_COLORS.white, fontSize: 26, fontWeight: "900", marginTop: 5 },
  surahHeaderArabic: { color: SALAWAT_COLORS.goldSoft, fontSize: 23, lineHeight: 38, textAlign: "center", writingDirection: "rtl", includeFontPadding: true, marginTop: 4, fontWeight: "400" },
  surahHeaderMeta: { color: "#BCE1D3", fontSize: 11, marginTop: 5 },
  bismillah: { alignItems: "center", paddingVertical: 18 },
  bismillahText: { color: SALAWAT_COLORS.gold, fontSize: 20, lineHeight: 36, textAlign: "center", writingDirection: "rtl", includeFontPadding: true, fontWeight: "400" },
  verseCard: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 18, padding: 16, marginBottom: 10 },
  verseTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  verseNumber: { width: 28, height: 28, borderRadius: 10, backgroundColor: SALAWAT_COLORS.emeraldSoft, alignItems: "center", justifyContent: "center" },
  verseNumberText: { color: SALAWAT_COLORS.emerald, fontSize: 11, fontWeight: "900" },
  arabicText: { color: SALAWAT_COLORS.ink, fontSize: 25, lineHeight: 52, textAlign: "right", writingDirection: "rtl", includeFontPadding: true, textAlignVertical: "center", marginTop: 16, fontWeight: "400" },
  translationText: { color: SALAWAT_COLORS.muted, fontSize: 14, lineHeight: 22, marginTop: 14 },
});
