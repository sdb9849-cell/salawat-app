import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { SALAWAT_COLORS, managedMosque, managementSections, managementStats, prayers } from "@/constants/salawat";
import { ActionRow, Icon, PageHeader, StatCard } from "@/components/salawat-ui";
import { ScreenContainer } from "@/components/screen-container";

export default function ManageScreen() {
  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.backRow}><Pressable onPress={() => router.back()} style={styles.backButton}><Icon name="arrow-back" size={19} color={SALAWAT_COLORS.emerald} /></Pressable><Text style={styles.backText}>Retour</Text></View>
        <PageHeader eyebrow="Espace responsable" title="Gestion" description="Pilotez les informations de votre mosquée et servez votre communauté." />

        <View style={styles.mosqueHeader}><View style={styles.mosqueLogo}><Icon name="mosque" size={28} color={SALAWAT_COLORS.emerald} /></View><View style={styles.mosqueCopy}><View style={styles.mosqueNameRow}><Text style={styles.mosqueName}>{managedMosque.name}</Text><View style={styles.verifiedPill}><Icon name="verified" size={13} color={SALAWAT_COLORS.gold} /><Text style={styles.verifiedText}>Vérifiée</Text></View></View><Text style={styles.mosqueAddress}>{managedMosque.address} · {managedMosque.city}</Text></View><Icon name="more-horiz" size={23} color={SALAWAT_COLORS.muted} /></View>

        <View style={styles.statsRow}>{managementStats.map((stat) => <StatCard key={stat.label} {...stat} />)}</View>

        <View style={styles.notice}><Icon name="info-outline" size={19} color={SALAWAT_COLORS.emerald} /><Text style={styles.noticeText}>Les changements sont visibles par la communauté après validation.</Text></View>

        <Text style={styles.groupLabel}>CENTRE DE GESTION</Text>
        {managementSections.map((section) => <ActionRow key={section.title} icon={section.icon as any} title={section.title} detail={section.detail} tone={section.tone} onPress={() => undefined} />)}

        <Text style={[styles.groupLabel, { marginTop: 18 }]}>APERÇU DES HORAIRES</Text>
        <View style={styles.scheduleCard}>{prayers.map((prayer) => <View key={prayer.name} style={styles.scheduleRow}><Text style={styles.scheduleName}>{prayer.name}</Text><Text style={styles.scheduleArabic}>{prayer.arabic}</Text><Text style={styles.scheduleTime}>{prayer.time}</Text><Icon name="edit" size={16} color={SALAWAT_COLORS.muted} /></View>)}<Pressable style={styles.publishButton}><Icon name="publish" size={17} color={SALAWAT_COLORS.white} /><Text style={styles.publishText}>Publier les horaires</Text></Pressable></View>

        <View style={styles.bottomHint}><Icon name="shield" size={17} color={SALAWAT_COLORS.gold} /><Text style={styles.bottomHintText}>Les rôles et autorisations sont protégés par votre compte administrateur.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 18, paddingTop: 14, paddingBottom: 50, maxWidth: 760, width: "100%", alignSelf: "center" },
  backRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 18 },
  backButton: { width: 36, height: 36, borderRadius: 12, backgroundColor: SALAWAT_COLORS.emeraldSoft, alignItems: "center", justifyContent: "center" },
  backText: { color: SALAWAT_COLORS.muted, fontSize: 12, fontWeight: "800" },
  mosqueHeader: { flexDirection: "row", alignItems: "center", gap: 11, backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 18, padding: 13, marginBottom: 12 },
  mosqueLogo: { width: 49, height: 49, borderRadius: 15, backgroundColor: SALAWAT_COLORS.emeraldSoft, alignItems: "center", justifyContent: "center" },
  mosqueCopy: { flex: 1 },
  mosqueNameRow: { flexDirection: "row", alignItems: "center", gap: 7, flexWrap: "wrap" },
  mosqueName: { color: SALAWAT_COLORS.ink, fontSize: 14, fontWeight: "900" },
  mosqueAddress: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 4 },
  verifiedPill: { flexDirection: "row", alignItems: "center", gap: 3, backgroundColor: SALAWAT_COLORS.goldSoft, borderRadius: 10, paddingHorizontal: 6, paddingVertical: 3 },
  verifiedText: { color: SALAWAT_COLORS.gold, fontSize: 9, fontWeight: "900" },
  statsRow: { flexDirection: "row", gap: 8, marginBottom: 12 },
  notice: { backgroundColor: SALAWAT_COLORS.emeraldSoft, borderRadius: 14, padding: 11, flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 21 },
  noticeText: { color: SALAWAT_COLORS.emeraldDeep, fontSize: 11, flex: 1, lineHeight: 16 },
  groupLabel: { color: SALAWAT_COLORS.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.2, marginBottom: 9 },
  scheduleCard: { backgroundColor: SALAWAT_COLORS.white, borderRadius: 18, borderWidth: 1, borderColor: SALAWAT_COLORS.line, padding: 12 },
  scheduleRow: { flexDirection: "row", alignItems: "center", paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: "#EDF3EF" },
  scheduleName: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900", width: 72 },
  scheduleArabic: { color: SALAWAT_COLORS.muted, fontSize: 12, flex: 1 },
  scheduleTime: { color: SALAWAT_COLORS.emerald, fontSize: 14, fontWeight: "900", marginRight: 15 },
  publishButton: { backgroundColor: SALAWAT_COLORS.emerald, borderRadius: 14, height: 45, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 12 },
  publishText: { color: SALAWAT_COLORS.white, fontSize: 12, fontWeight: "900" },
  bottomHint: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingTop: 23 },
  bottomHintText: { color: SALAWAT_COLORS.muted, fontSize: 10, textAlign: "center", flex: 1 },
});
