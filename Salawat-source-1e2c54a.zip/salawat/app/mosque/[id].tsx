import { router, useLocalSearchParams } from "expo-router";
import { useMemo } from "react";
import { Pressable, ScrollView, Share, StyleSheet, Text, View } from "react-native";

import { SALAWAT_COLORS, mosqueSchedules, mosques } from "@/constants/salawat";
import { Icon, PageHeader } from "@/components/salawat-ui";
import { ScreenContainer } from "@/components/screen-container";

function formatDay(day: number, monthDate: Date) {
  return new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short" }).format(new Date(monthDate.getFullYear(), monthDate.getMonth(), day));
}

export default function MosqueDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const mosque = mosques.find((item) => item.id === id) ?? mosques[0];
  const schedule = mosqueSchedules[mosque.id] ?? mosqueSchedules["paris-1"];
  const calendarDate = useMemo(() => new Date(), []);
  const calendarDays = useMemo(() => Array.from({ length: new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 0).getDate() }, (_, index) => index + 1), [calendarDate]);
  const monthLabel = new Intl.DateTimeFormat("fr-FR", { month: "long", year: "numeric" }).format(calendarDate);
  const shareCalendar = () => Share.share({ message: `Calendrier des prières — ${mosque.name}\n${monthLabel}\n${schedule.map((prayer) => `${prayer.name}: ${prayer.adhan} · Iqama ${prayer.iqama}`).join("\n")}` }).catch(() => undefined);

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.backRow}>
          <Pressable onPress={() => router.back()} style={styles.backButton}>
            <Icon name="arrow-back" size={19} color={SALAWAT_COLORS.emerald} />
          </Pressable>
          <Text style={styles.backText}>Mosquées</Text>
        </View>

        <PageHeader eyebrow="Horaires de la mosquée" title={mosque.name} description={`${mosque.address} · ${mosque.city}, ${mosque.country}`} />

        <View style={styles.statusRow}>
          <View style={styles.statusPill}><View style={styles.statusDot} /><Text style={styles.statusText}>{mosque.openNow ? "Ouverte maintenant" : "Fermée actuellement"}</Text></View>
          {mosque.verified ? <View style={styles.verifiedPill}><Icon name="verified" size={14} color={SALAWAT_COLORS.gold} /><Text style={styles.verifiedText}>Mosquée vérifiée</Text></View> : null}
        </View>

        <View style={styles.todayCard}>
          <View style={styles.cardHeading}><View><Text style={styles.cardKicker}>AUJOURD’HUI</Text><Text style={styles.cardTitle}>Prière et iqama</Text></View><Icon name="schedule" size={23} color={SALAWAT_COLORS.gold} /></View>
          <View style={styles.tableHeader}><Text style={styles.tableHeaderName}>PRIÈRE</Text><Text style={styles.tableHeaderTime}>ADHAN</Text><Text style={styles.tableHeaderTime}>IQAMA</Text></View>
          {schedule.map((prayer) => <View key={prayer.name} style={styles.scheduleRow}><View style={styles.prayerName}><Text style={styles.prayerTitle}>{prayer.name}</Text><Text style={styles.prayerArabic}>{prayer.arabic}</Text></View><Text style={styles.adhan}>{prayer.adhan}</Text><Text style={styles.iqama}>{prayer.iqama}</Text></View>)}
          <Text style={styles.scheduleNote}>Les horaires d’iqama sont ceux publiés par la mosquée et peuvent être ajustés par son responsable.</Text>
        </View>

        <View style={styles.sectionHeading}><View><Text style={styles.cardKicker}>CALENDRIER</Text><Text style={styles.cardTitle}>{monthLabel}</Text></View><Pressable onPress={shareCalendar} style={styles.downloadButton}><Icon name="share" size={17} color={SALAWAT_COLORS.emerald} /><Text style={styles.downloadText}>Partager</Text></Pressable></View>
        <View style={styles.calendarCard}>
          <View style={styles.calendarHeader}><Text style={styles.calendarHeaderDay}>DATE</Text>{schedule.map((prayer) => <Text key={prayer.name} style={styles.calendarHeaderTime}>{prayer.name === "Dhuhr" ? "DHOHR" : prayer.name.toUpperCase()}</Text>)}</View>
          {calendarDays.map((day) => <View key={day} style={styles.calendarRow}><Text style={styles.calendarDate}>{formatDay(day, calendarDate)}</Text>{schedule.map((prayer) => <Text key={`${day}-${prayer.name}`} style={styles.calendarTime}>{prayer.adhan}</Text>)}</View>)}
        </View>

        <View style={styles.infoCard}><Icon name="info-outline" size={19} color={SALAWAT_COLORS.emerald} /><Text style={styles.infoText}>Ce calendrier est consultable et partageable. Les horaires officiels restent ceux communiqués par la mosquée.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 18, paddingTop: 14, paddingBottom: 50, maxWidth: 820, width: "100%", alignSelf: "center" },
  backRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 18 },
  backButton: { width: 36, height: 36, borderRadius: 12, backgroundColor: SALAWAT_COLORS.emeraldSoft, alignItems: "center", justifyContent: "center" },
  backText: { color: SALAWAT_COLORS.muted, fontSize: 12, fontWeight: "800" },
  statusRow: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 16 },
  statusPill: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#EAF3EF", borderRadius: 16, paddingHorizontal: 10, paddingVertical: 7 },
  statusDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#35A77C" },
  statusText: { color: SALAWAT_COLORS.emerald, fontSize: 11, fontWeight: "800" },
  verifiedPill: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: SALAWAT_COLORS.goldSoft, borderRadius: 16, paddingHorizontal: 10, paddingVertical: 7 },
  verifiedText: { color: SALAWAT_COLORS.gold, fontSize: 11, fontWeight: "800" },
  todayCard: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 20, padding: 15, marginBottom: 25 },
  cardHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  cardKicker: { color: SALAWAT_COLORS.gold, fontSize: 10, letterSpacing: 1.2, fontWeight: "900" },
  cardTitle: { color: SALAWAT_COLORS.ink, fontSize: 19, fontWeight: "900", marginTop: 3 },
  tableHeader: { flexDirection: "row", paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: SALAWAT_COLORS.line },
  tableHeaderName: { flex: 1, color: SALAWAT_COLORS.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.8 },
  tableHeaderTime: { width: 72, textAlign: "right", color: SALAWAT_COLORS.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.8 },
  scheduleRow: { flexDirection: "row", alignItems: "center", paddingVertical: 11, borderBottomWidth: 1, borderBottomColor: "#EDF3EF" },
  prayerName: { flex: 1 },
  prayerTitle: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "900" },
  prayerArabic: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 2 },
  adhan: { width: 72, textAlign: "right", color: SALAWAT_COLORS.ink, fontSize: 15, fontWeight: "800" },
  iqama: { width: 72, textAlign: "right", color: SALAWAT_COLORS.emerald, fontSize: 15, fontWeight: "900" },
  scheduleNote: { color: SALAWAT_COLORS.muted, fontSize: 10, lineHeight: 15, marginTop: 12 },
  sectionHeading: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 11 },
  downloadButton: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: SALAWAT_COLORS.emeraldSoft, borderRadius: 14, paddingHorizontal: 10, paddingVertical: 8 },
  downloadText: { color: SALAWAT_COLORS.emerald, fontSize: 11, fontWeight: "900" },
  calendarCard: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 18, padding: 10, overflow: "hidden" },
  calendarHeader: { flexDirection: "row", paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: SALAWAT_COLORS.line },
  calendarHeaderDay: { width: 66, color: SALAWAT_COLORS.muted, fontSize: 8, fontWeight: "900" },
  calendarHeaderTime: { flex: 1, textAlign: "center", color: SALAWAT_COLORS.muted, fontSize: 8, fontWeight: "900" },
  calendarRow: { flexDirection: "row", alignItems: "center", minHeight: 34, borderBottomWidth: 1, borderBottomColor: "#F0F4F1" },
  calendarDate: { width: 66, color: SALAWAT_COLORS.ink, fontSize: 10, fontWeight: "800" },
  calendarTime: { flex: 1, textAlign: "center", color: SALAWAT_COLORS.emerald, fontSize: 10, fontWeight: "700" },
  infoCard: { flexDirection: "row", gap: 8, alignItems: "center", backgroundColor: SALAWAT_COLORS.emeraldSoft, borderRadius: 15, padding: 12, marginTop: 14 },
  infoText: { flex: 1, color: SALAWAT_COLORS.emeraldDeep, fontSize: 11, lineHeight: 16 },
});
