import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { ComponentProps, ReactNode } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { SALAWAT_COLORS, type Mosque, type Prayer } from "@/constants/salawat";

type IconName = ComponentProps<typeof MaterialIcons>["name"];

export function SalawatMark({ size = 42 }: { size?: number }) {
  return (
    <View style={[styles.mark, { width: size, height: size, borderRadius: size * 0.32 }]}>
      <View style={[styles.markBook, { width: size * 0.52, height: size * 0.42 }]}>
        <View style={styles.markSpine} />
        <View style={styles.markBookmark} />
      </View>
    </View>
  );
}

export function Icon({ name, size = 22, color = SALAWAT_COLORS.emerald }: { name: IconName; size?: number; color?: string }) {
  return <MaterialIcons name={name} size={size} color={color} />;
}

export function PageHeader({
  eyebrow,
  title,
  description,
  right,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  right?: ReactNode;
}) {
  return (
    <View style={styles.pageHeader}>
      <View style={styles.headerCopy}>
        {eyebrow ? <Text style={styles.eyebrow}>{eyebrow.toUpperCase()}</Text> : null}
        <Text style={styles.pageTitle}>{title}</Text>
        {description ? <Text style={styles.pageDescription}>{description}</Text> : null}
      </View>
      {right}
    </View>
  );
}

export function SectionTitle({ title, action, onPress }: { title: string; action?: string; onPress?: () => void }) {
  return (
    <View style={styles.sectionTitleRow}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {action ? (
        <Pressable onPress={onPress} hitSlop={10}>
          <Text style={styles.sectionAction}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function PrayerCard({ prayer, compact = false }: { prayer: Prayer; compact?: boolean }) {
  const active = prayer.state === "next";
  const done = prayer.state === "done";
  return (
    <View style={[styles.prayerCard, active && styles.prayerCardActive, compact && styles.prayerCardCompact]}>
      <View style={[styles.prayerDot, active && styles.prayerDotActive, done && styles.prayerDotDone]}>
        {done ? <Icon name="check" size={12} color={SALAWAT_COLORS.white} /> : null}
      </View>
      <View style={styles.prayerText}>
        <Text style={[styles.prayerName, active && styles.prayerNameActive]}>{prayer.name}</Text>
        {!compact ? <Text style={styles.prayerArabic}>{prayer.arabic}</Text> : null}
      </View>
      <Text style={[styles.prayerTime, active && styles.prayerTimeActive]}>{prayer.time}</Text>
    </View>
  );
}

export function MosqueCard({ mosque, onPress, favorite = false, onToggleFavorite }: { mosque: Mosque; onPress?: () => void; favorite?: boolean; onToggleFavorite?: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.mosqueCard, pressed && styles.pressed]}>
      <View style={[styles.mosqueThumb, { backgroundColor: mosque.imageTone }]}>
        <Icon name="mosque" size={28} color={SALAWAT_COLORS.emerald} />
      </View>
      <View style={styles.mosqueBody}>
        <View style={styles.mosqueTitleRow}>
          <Text style={styles.mosqueName} numberOfLines={1}>{mosque.name}</Text>
          {mosque.verified ? <Icon name="verified" size={16} color={SALAWAT_COLORS.gold} /> : null}
        </View>
        <Text style={styles.mosqueMeta}>{mosque.city} · {mosque.distance}</Text>
        <View style={styles.mosqueBottomRow}>
          <Text style={styles.mosqueNext}>{mosque.nextPrayer}</Text>
          <View style={styles.openPill}>
            <View style={styles.openDot} />
            <Text style={styles.openText}>{mosque.openNow ? "Ouverte" : "Fermée"}</Text>
          </View>
        </View>
      </View>
      {onToggleFavorite ? <Pressable hitSlop={8} onPress={(event) => { event.stopPropagation(); onToggleFavorite(); }}><Icon name={favorite ? "star" : "star-border"} size={21} color={favorite ? SALAWAT_COLORS.gold : SALAWAT_COLORS.muted} /></Pressable> : null}
      <Icon name="chevron-right" size={21} color={SALAWAT_COLORS.muted} />
    </Pressable>
  );
}

export function StatCard({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <View style={styles.statCard}>
      <View style={[styles.statAccent, { backgroundColor: tone }]} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

export function ActionRow({ icon, title, detail, tone = "emerald", onPress }: { icon: IconName; title: string; detail: string; tone?: "emerald" | "gold" | "blue" | "ink"; onPress?: () => void }) {
  const colors = { emerald: SALAWAT_COLORS.emeraldSoft, gold: SALAWAT_COLORS.goldSoft, blue: "#E8EFF2", ink: "#E7ECEA" };
  const iconColors = { emerald: SALAWAT_COLORS.emerald, gold: SALAWAT_COLORS.gold, blue: SALAWAT_COLORS.blue, ink: SALAWAT_COLORS.ink };
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.actionRow, pressed && styles.pressed]}>
      <View style={[styles.actionIcon, { backgroundColor: colors[tone] }]}>
        <Icon name={icon} size={21} color={iconColors[tone]} />
      </View>
      <View style={styles.actionCopy}>
        <Text style={styles.actionTitle}>{title}</Text>
        <Text style={styles.actionDetail}>{detail}</Text>
      </View>
      <Icon name="chevron-right" size={21} color={SALAWAT_COLORS.muted} />
    </Pressable>
  );
}

export function Pill({ children, selected = false, onPress }: { children: ReactNode; selected?: boolean; onPress?: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.pill, selected && styles.pillSelected]}>
      <Text style={[styles.pillText, selected && styles.pillTextSelected]}>{children}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  mark: { backgroundColor: SALAWAT_COLORS.emerald, alignItems: "center", justifyContent: "center" },
  markBook: { backgroundColor: SALAWAT_COLORS.gold, borderRadius: 5, transform: [{ rotate: "-7deg" }], position: "relative", justifyContent: "center" },
  markSpine: { position: "absolute", left: "48%", top: 2, bottom: 2, width: 2, backgroundColor: SALAWAT_COLORS.goldSoft },
  markBookmark: { position: "absolute", width: 6, height: 17, backgroundColor: SALAWAT_COLORS.white, right: 8, top: 3, opacity: 0.9 },
  pageHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 14, marginBottom: 24 },
  headerCopy: { flex: 1 },
  eyebrow: { color: SALAWAT_COLORS.gold, fontSize: 11, letterSpacing: 1.5, fontWeight: "800", marginBottom: 7 },
  pageTitle: { color: SALAWAT_COLORS.ink, fontSize: 30, fontWeight: "800", letterSpacing: -0.5 },
  pageDescription: { color: SALAWAT_COLORS.muted, fontSize: 14, lineHeight: 21, marginTop: 7 },
  sectionTitleRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  sectionTitle: { color: SALAWAT_COLORS.ink, fontSize: 17, fontWeight: "800" },
  sectionAction: { color: SALAWAT_COLORS.emerald, fontSize: 13, fontWeight: "800" },
  prayerCard: { minWidth: 92, flex: 1, backgroundColor: SALAWAT_COLORS.white, borderRadius: 18, padding: 13, borderWidth: 1, borderColor: SALAWAT_COLORS.line, minHeight: 112 },
  prayerCardCompact: { minHeight: 76, padding: 10, minWidth: 0 },
  prayerCardActive: { backgroundColor: SALAWAT_COLORS.emerald, borderColor: SALAWAT_COLORS.emerald },
  prayerDot: { width: 22, height: 22, borderRadius: 11, backgroundColor: SALAWAT_COLORS.emeraldSoft, alignItems: "center", justifyContent: "center", marginBottom: 12 },
  prayerDotActive: { backgroundColor: "rgba(255,255,255,0.18)" },
  prayerDotDone: { backgroundColor: SALAWAT_COLORS.muted },
  prayerText: { flex: 1 },
  prayerName: { color: SALAWAT_COLORS.ink, fontSize: 13, fontWeight: "800" },
  prayerNameActive: { color: SALAWAT_COLORS.white },
  prayerArabic: { color: SALAWAT_COLORS.muted, fontSize: 11, marginTop: 3 },
  prayerTime: { color: SALAWAT_COLORS.ink, fontSize: 19, fontWeight: "800", marginTop: 7 },
  prayerTimeActive: { color: SALAWAT_COLORS.white },
  mosqueCard: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 18, padding: 12, flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 10 },
  mosqueThumb: { width: 52, height: 52, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  mosqueBody: { flex: 1, minWidth: 0 },
  mosqueTitleRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  mosqueName: { color: SALAWAT_COLORS.ink, fontSize: 14, fontWeight: "800", flexShrink: 1 },
  mosqueMeta: { color: SALAWAT_COLORS.muted, fontSize: 12, marginTop: 4 },
  mosqueBottomRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 8, gap: 8 },
  mosqueNext: { color: SALAWAT_COLORS.emerald, fontSize: 12, fontWeight: "800" },
  openPill: { flexDirection: "row", alignItems: "center", gap: 5 },
  openDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#35A77C" },
  openText: { color: SALAWAT_COLORS.muted, fontSize: 11 },
  statCard: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 16, padding: 14, flex: 1, minWidth: 105, overflow: "hidden" },
  statAccent: { height: 4, width: 28, borderRadius: 2, marginBottom: 13 },
  statValue: { color: SALAWAT_COLORS.ink, fontSize: 21, fontWeight: "800" },
  statLabel: { color: SALAWAT_COLORS.muted, fontSize: 11, lineHeight: 16, marginTop: 3 },
  actionRow: { backgroundColor: SALAWAT_COLORS.white, borderWidth: 1, borderColor: SALAWAT_COLORS.line, borderRadius: 16, padding: 13, flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 9 },
  actionIcon: { width: 42, height: 42, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  actionCopy: { flex: 1 },
  actionTitle: { color: SALAWAT_COLORS.ink, fontSize: 14, fontWeight: "800" },
  actionDetail: { color: SALAWAT_COLORS.muted, fontSize: 12, marginTop: 3 },
  pill: { borderRadius: 30, borderWidth: 1, borderColor: SALAWAT_COLORS.line, paddingHorizontal: 14, paddingVertical: 9, backgroundColor: SALAWAT_COLORS.white },
  pillSelected: { backgroundColor: SALAWAT_COLORS.emerald, borderColor: SALAWAT_COLORS.emerald },
  pillText: { color: SALAWAT_COLORS.muted, fontSize: 12, fontWeight: "700" },
  pillTextSelected: { color: SALAWAT_COLORS.white },
  pressed: { opacity: 0.78 },
});
