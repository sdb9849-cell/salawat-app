export const SALAWAT_COLORS = {
  emerald: "#0F6B58",
  emeraldDeep: "#0A4B40",
  emeraldSoft: "#DDF1EA",
  gold: "#C99A3D",
  goldSoft: "#F7E9C7",
  ink: "#17332D",
  muted: "#6C817A",
  paper: "#F8FAF7",
  white: "#FFFFFF",
  line: "#DCE8E2",
  blue: "#417E95",
} as const;

export type PrayerName = "Fajr" | "Dhuhr" | "Asr" | "Maghrib" | "Isha";

export type Prayer = {
  name: PrayerName;
  arabic: string;
  time: string;
  state: "done" | "next" | "upcoming";
  accent?: string;
};

export type Mosque = {
  id: string;
  name: string;
  city: string;
  country: string;
  address: string;
  distance: string;
  verified: boolean;
  openNow: boolean;
  services: string[];
  nextPrayer: string;
  imageTone: string;
};

export type MosquePrayerSchedule = {
  name: PrayerName;
  arabic: string;
  adhan: string;
  iqama: string;
};

export const currentLocation = {
  city: "Paris",
  country: "France",
  timezone: "Europe/Paris",
  hijri: "19 Jumada al-awwal 1448",
  date: "Samedi 21 novembre 2026",
};

export const prayers: Prayer[] = [
  { name: "Fajr", arabic: "الفجر", time: "06:41", state: "done" },
  { name: "Dhuhr", arabic: "الظهر", time: "13:37", state: "done" },
  { name: "Asr", arabic: "العصر", time: "16:19", state: "next", accent: SALAWAT_COLORS.gold },
  { name: "Maghrib", arabic: "المغرب", time: "17:09", state: "upcoming" },
  { name: "Isha", arabic: "العشاء", time: "18:34", state: "upcoming" },
];

export const mosques: Mosque[] = [
  {
    id: "paris-1",
    name: "Grande Mosquée de Paris",
    city: "Paris",
    country: "France",
    address: "2 bis, place du Puits de l'Ermite",
    distance: "1,8 km",
    verified: true,
    openNow: true,
    services: ["Jumu'ah", "Qur’an", "Femmes"],
    nextPrayer: "Asr · 16:19",
    imageTone: "#DDF1EA",
  },
  {
    id: "paris-2",
    name: "Mosquée Omar Ibn Khattab",
    city: "Paris",
    country: "France",
    address: "39, rue Jean-Pierre Timbaud",
    distance: "3,4 km",
    verified: true,
    openNow: true,
    services: ["Jumu'ah", "Parking", "Cours"],
    nextPrayer: "Asr · 16:19",
    imageTone: "#F7E9C7",
  },
  {
    id: "london-1",
    name: "East London Mosque",
    city: "London",
    country: "United Kingdom",
    address: "82-92 Whitechapel Road",
    distance: "344 km",
    verified: true,
    openNow: true,
    services: ["Jumu'ah", "Qur’an", "Cours"],
    nextPrayer: "Asr · 15:06",
    imageTone: "#E8EFF2",
  },
  {
    id: "istanbul-1",
    name: "Süleymaniye Camii",
    city: "Istanbul",
    country: "Türkiye",
    address: "Süleymaniye, Fatih",
    distance: "2 256 km",
    verified: true,
    openNow: true,
    services: ["Jumu'ah", "Qur’an", "Visites"],
    nextPrayer: "Asr · 16:01",
    imageTone: "#F2E2DD",
  },
  {
    id: "kl-1",
    name: "Masjid Negara",
    city: "Kuala Lumpur",
    country: "Malaysia",
    address: "Jalan Perdana, Tasik Perdana",
    distance: "10 041 km",
    verified: true,
    openNow: true,
    services: ["Jumu'ah", "Femmes", "Parking"],
    nextPrayer: "Asr · 16:37",
    imageTone: "#E4EBF3",
  },
];

export const managedMosque = mosques[0];

export const mosqueSchedules: Record<string, MosquePrayerSchedule[]> = {
  "paris-1": [
    { name: "Fajr", arabic: "الفجر", adhan: "06:41", iqama: "06:56" },
    { name: "Dhuhr", arabic: "الظهر", adhan: "13:37", iqama: "13:55" },
    { name: "Asr", arabic: "العصر", adhan: "16:19", iqama: "16:34" },
    { name: "Maghrib", arabic: "المغرب", adhan: "17:09", iqama: "17:14" },
    { name: "Isha", arabic: "العشاء", adhan: "18:34", iqama: "18:49" },
  ],
  "paris-2": [
    { name: "Fajr", arabic: "الفجر", adhan: "06:42", iqama: "07:00" },
    { name: "Dhuhr", arabic: "الظهر", adhan: "13:37", iqama: "14:00" },
    { name: "Asr", arabic: "العصر", adhan: "16:19", iqama: "16:40" },
    { name: "Maghrib", arabic: "المغرب", adhan: "17:09", iqama: "17:16" },
    { name: "Isha", arabic: "العشاء", adhan: "18:34", iqama: "19:00" },
  ],
  "london-1": [
    { name: "Fajr", arabic: "الفجر", adhan: "05:56", iqama: "06:15" },
    { name: "Dhuhr", arabic: "الظهر", adhan: "12:11", iqama: "12:35" },
    { name: "Asr", arabic: "العصر", adhan: "15:06", iqama: "15:25" },
    { name: "Maghrib", arabic: "المغرب", adhan: "16:12", iqama: "16:18" },
    { name: "Isha", arabic: "العشاء", adhan: "20:19", iqama: "20:35" },
  ],
  "istanbul-1": [
    { name: "Fajr", arabic: "الفجر", adhan: "06:12", iqama: "06:30" },
    { name: "Dhuhr", arabic: "الظهر", adhan: "12:52", iqama: "13:10" },
    { name: "Asr", arabic: "العصر", adhan: "16:01", iqama: "16:20" },
    { name: "Maghrib", arabic: "المغرب", adhan: "17:32", iqama: "17:38" },
    { name: "Isha", arabic: "العشاء", adhan: "19:00", iqama: "19:20" },
  ],
  "kl-1": [
    { name: "Fajr", arabic: "الفجر", adhan: "05:48", iqama: "06:05" },
    { name: "Dhuhr", arabic: "الظهر", adhan: "13:07", iqama: "13:25" },
    { name: "Asr", arabic: "العصر", adhan: "16:37", iqama: "16:55" },
    { name: "Maghrib", arabic: "المغرب", adhan: "19:05", iqama: "19:10" },
    { name: "Isha", arabic: "العشاء", adhan: "20:19", iqama: "20:35" },
  ],
};

export const managementStats = [
  { label: "Fiche complète", value: "92 %", tone: SALAWAT_COLORS.emerald },
  { label: "Horaires publiés", value: "5 / 5", tone: SALAWAT_COLORS.gold },
  { label: "Membres actifs", value: "18", tone: SALAWAT_COLORS.blue },
];

export const managementSections = [
  { icon: "schedule", title: "Horaires de prière", detail: "Modifier les horaires du 21 novembre", tone: "gold" },
  { icon: "mosque", title: "Informations de la mosquée", detail: "Adresse, services et contacts", tone: "emerald" },
  { icon: "campaign", title: "Annonces", detail: "1 annonce visible par la communauté", tone: "blue" },
  { icon: "group", title: "Équipe et accès", detail: "18 membres · 3 responsables", tone: "ink" },
] as const;
