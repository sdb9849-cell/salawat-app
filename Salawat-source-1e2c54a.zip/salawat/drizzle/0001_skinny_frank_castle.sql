CREATE TABLE `announcements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`mosqueId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`body` text NOT NULL,
	`status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `announcements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mosqueMembers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`mosqueId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('viewer','editor','manager') NOT NULL DEFAULT 'viewer',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mosqueMembers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mosques` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(160) NOT NULL,
	`name` varchar(180) NOT NULL,
	`country` varchar(100) NOT NULL,
	`city` varchar(100) NOT NULL,
	`address` text NOT NULL,
	`latitude` varchar(32),
	`longitude` varchar(32),
	`phone` varchar(40),
	`website` varchar(255),
	`services` text,
	`verified` int NOT NULL DEFAULT 0,
	`status` enum('draft','pending','published','archived') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mosques_id` PRIMARY KEY(`id`),
	CONSTRAINT `mosques_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `prayerSchedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`mosqueId` int NOT NULL,
	`scheduleDate` varchar(10) NOT NULL,
	`fajr` varchar(5) NOT NULL,
	`sunrise` varchar(5),
	`dhuhr` varchar(5) NOT NULL,
	`asr` varchar(5) NOT NULL,
	`maghrib` varchar(5) NOT NULL,
	`isha` varchar(5) NOT NULL,
	`published` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `prayerSchedules_id` PRIMARY KEY(`id`)
);
