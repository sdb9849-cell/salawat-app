import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  passwordHash: text("passwordHash"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const salawatSessions = mysqlTable("salawatSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SalawatSession = typeof salawatSessions.$inferSelect;

export const mosques = mysqlTable("mosques", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  country: varchar("country", { length: 100 }).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  address: text("address").notNull(),
  latitude: varchar("latitude", { length: 32 }),
  longitude: varchar("longitude", { length: 32 }),
  phone: varchar("phone", { length: 40 }),
  website: varchar("website", { length: 255 }),
  services: text("services"),
  verified: int("verified").default(0).notNull(),
  status: mysqlEnum("status", ["draft", "pending", "published", "archived"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Mosque = typeof mosques.$inferSelect;
export type InsertMosque = typeof mosques.$inferInsert;

export const prayerSchedules = mysqlTable("prayerSchedules", {
  id: int("id").autoincrement().primaryKey(),
  mosqueId: int("mosqueId").notNull(),
  scheduleDate: varchar("scheduleDate", { length: 10 }).notNull(),
  fajr: varchar("fajr", { length: 5 }).notNull(),
  sunrise: varchar("sunrise", { length: 5 }),
  dhuhr: varchar("dhuhr", { length: 5 }).notNull(),
  asr: varchar("asr", { length: 5 }).notNull(),
  maghrib: varchar("maghrib", { length: 5 }).notNull(),
  isha: varchar("isha", { length: 5 }).notNull(),
  published: int("published").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PrayerSchedule = typeof prayerSchedules.$inferSelect;
export type InsertPrayerSchedule = typeof prayerSchedules.$inferInsert;

export const mosqueMembers = mysqlTable("mosqueMembers", {
  id: int("id").autoincrement().primaryKey(),
  mosqueId: int("mosqueId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["viewer", "editor", "manager"]).default("viewer").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const announcements = mysqlTable("announcements", {
  id: int("id").autoincrement().primaryKey(),
  mosqueId: int("mosqueId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  status: mysqlEnum("status", ["draft", "published", "archived"]).default("draft").notNull(),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
