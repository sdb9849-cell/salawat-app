import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type AudioStatus = {
  playing: boolean;
  isBuffering: boolean;
  currentTime: number;
  duration: number;
};

type WebAudioPlayer = {
  play: () => void;
  pause: () => void;
  replace: (source: string) => void;
  remove: () => void;
  getStatus: () => AudioStatus;
  subscribe: (listener: () => void) => () => void;
};

const INITIAL_STATUS: AudioStatus = {
  playing: false,
  isBuffering: false,
  currentTime: 0,
  duration: 0,
};

export function useAudioPlayer(
  source: string | null | undefined,
  _options?: { updateInterval?: number },
): WebAudioPlayer {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const statusRef = useRef<AudioStatus>(INITIAL_STATUS);
  const listenersRef = useRef(new Set<() => void>());
  const sourceRef = useRef(source);
  sourceRef.current = source;

  const notify = useCallback(() => {
    for (const listener of listenersRef.current) listener();
  }, []);

  const updateStatus = useCallback(
    (next: Partial<AudioStatus>) => {
      statusRef.current = { ...statusRef.current, ...next };
      notify();
    },
    [notify],
  );

  const player = useMemo<WebAudioPlayer>(
    () => ({
      play: () => {
        void audioRef.current?.play().catch(() => undefined);
      },
      pause: () => {
        audioRef.current?.pause();
      },
      replace: (nextSource) => {
        const audio = audioRef.current;
        if (!audio) return;
        audio.src = nextSource;
        audio.load();
        statusRef.current = INITIAL_STATUS;
        notify();
      },
      remove: () => {
        audioRef.current?.pause();
        audioRef.current = null;
        statusRef.current = INITIAL_STATUS;
        notify();
      },
      getStatus: () => statusRef.current,
      subscribe: (listener) => {
        listenersRef.current.add(listener);
        return () => listenersRef.current.delete(listener);
      },
    }),
    [notify],
  );

  useEffect(() => {
    if (
      typeof window === "undefined" ||
      typeof window.Audio === "undefined" ||
      !sourceRef.current
    ) {
      return undefined;
    }

    const audio = new window.Audio(sourceRef.current);
    audio.preload = "metadata";
    audioRef.current = audio;
    updateStatus(INITIAL_STATUS);

    const handleLoaded = () =>
      updateStatus({ duration: Number.isFinite(audio.duration) ? audio.duration : 0, isBuffering: false });
    const handleTime = () =>
      updateStatus({ currentTime: audio.currentTime, playing: !audio.paused });
    const handlePlay = () => updateStatus({ playing: true, isBuffering: false });
    const handlePause = () => updateStatus({ playing: false, isBuffering: false });
    const handleWaiting = () => updateStatus({ isBuffering: true });
    const handleEnded = () => updateStatus({ playing: false, currentTime: 0 });

    audio.addEventListener("loadedmetadata", handleLoaded);
    audio.addEventListener("timeupdate", handleTime);
    audio.addEventListener("play", handlePlay);
    audio.addEventListener("pause", handlePause);
    audio.addEventListener("waiting", handleWaiting);
    audio.addEventListener("ended", handleEnded);

    return () => {
      audio.pause();
      audio.removeEventListener("loadedmetadata", handleLoaded);
      audio.removeEventListener("timeupdate", handleTime);
      audio.removeEventListener("play", handlePlay);
      audio.removeEventListener("pause", handlePause);
      audio.removeEventListener("waiting", handleWaiting);
      audio.removeEventListener("ended", handleEnded);
      if (audioRef.current === audio) audioRef.current = null;
    };
  }, [source, updateStatus]);

  return player;
}

export function useAudioPlayerStatus(player: WebAudioPlayer): AudioStatus {
  const [, forceUpdate] = useState(0);
  useEffect(() => player.subscribe(() => forceUpdate((value) => value + 1)), [player]);
  return player.getStatus();
}
