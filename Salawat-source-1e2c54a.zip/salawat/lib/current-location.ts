import * as Location from "expo-location";

export type CurrentGpsLocation = {
  latitude: number;
  longitude: number;
  accuracy: number | null;
  countryCode?: string;
  label: string;
};

function isValidCoordinate(latitude: number, longitude: number) {
  return (
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -90 &&
    latitude <= 90 &&
    longitude >= -180 &&
    longitude <= 180
  );
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error("Délai dépassé pendant la localisation GPS.")),
      timeoutMs,
    );
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error: unknown) => {
        clearTimeout(timer);
        reject(error);
      },
    );
  });
}

export async function getGpsLocationFromCoordinates(
  latitude: number,
  longitude: number,
  accuracy: number | null,
): Promise<CurrentGpsLocation> {
  if (!isValidCoordinate(latitude, longitude)) {
    throw new Error(
      "Le GPS a renvoyé des coordonnées invalides. Vérifiez que la localisation est activée.",
    );
  }
  let label = "Position actuelle";
  let countryCode: string | undefined;
  try {
    const [address] = await Location.reverseGeocodeAsync({
      latitude,
      longitude,
    });
    if (address) {
      countryCode = address.isoCountryCode?.toUpperCase() ?? undefined;
      const locality = address.city ?? address.subregion ?? address.region;
      label = [locality, address.country].filter(Boolean).join(", ") || label;
    }
  } catch {
    // Les coordonnées GPS restent valides si le géocodage inverse échoue.
  }
  return { latitude, longitude, accuracy, countryCode, label };
}

/** Demande une position fraîche au GPS après avoir vérifié/demandé la permission. */
export async function getCurrentGpsLocation(): Promise<CurrentGpsLocation> {
  let permission = await Location.getForegroundPermissionsAsync();
  if (permission.status !== Location.PermissionStatus.GRANTED) {
    permission = await Location.requestForegroundPermissionsAsync();
  }
  if (permission.status !== Location.PermissionStatus.GRANTED) {
    throw new Error(
      "Autorisation de localisation refusée. Autorisez le GPS ou utilisez la recherche par ville.",
    );
  }

  const position = await withTimeout(
    Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.Balanced,
      mayShowUserSettingsDialog: true,
    }),
    20_000,
  );
  return getGpsLocationFromCoordinates(
    position.coords.latitude,
    position.coords.longitude,
    position.coords.accuracy,
  );
}
