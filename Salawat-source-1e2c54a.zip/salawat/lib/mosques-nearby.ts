import AsyncStorage from "@react-native-async-storage/async-storage";

export type NearbyMosque = {
  id: string;
  source: "osm" | "salawat";
  sourceId?: string;
  name: string;
  city: string;
  country: string;
  address: string;
  latitude: number;
  longitude: number;
  distanceMeters: number;
  distance: string;
  verified: boolean;
  openNow: boolean;
  services: string[];
  nextPrayer: string;
  imageTone: string;
  sourceLabel: string;
};

export type NearbyLocation = {
  latitude: number;
  longitude: number;
  accuracy?: number | null;
};

const CACHE_KEY = "salawat.mosques.nearby.v1";
const CELL_SIZE = 0.04;

export function cacheKey(location: NearbyLocation, radiusMeters: number) {
  const latCell = Math.round(location.latitude / CELL_SIZE);
  const lonCell = Math.round(location.longitude / CELL_SIZE);
  return `${latCell}:${lonCell}:${radiusMeters}`;
}

export function formatDistance(distanceMeters: number) {
  if (distanceMeters < 1000) return `${Math.round(distanceMeters)} m`;
  return `${(distanceMeters / 1000).toFixed(distanceMeters >= 10000 ? 0 : 1).replace(".", ",")} km`;
}

export function distanceBetweenMeters(a: NearbyLocation, b: { latitude: number; longitude: number }) {
  const earthRadius = 6371000;
  const lat1 = (a.latitude * Math.PI) / 180;
  const lat2 = (b.latitude * Math.PI) / 180;
  const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
  const dLon = ((b.longitude - a.longitude) * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * earthRadius * Math.asin(Math.sqrt(h));
}

export async function readNearbyCache(key: string) {
  try {
    const raw = await AsyncStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const all = JSON.parse(raw) as Record<string, { savedAt: string; data: NearbyMosque[] }>;
    return all[key] ?? null;
  } catch {
    return null;
  }
}

export async function writeNearbyCache(key: string, data: NearbyMosque[]) {
  try {
    const raw = await AsyncStorage.getItem(CACHE_KEY);
    const all = raw ? (JSON.parse(raw) as Record<string, { savedAt: string; data: NearbyMosque[] }>) : {};
    const entries = Object.entries(all)
      .sort(([, first], [, second]) => second.savedAt.localeCompare(first.savedAt))
      .slice(0, 8);
    await AsyncStorage.setItem(CACHE_KEY, JSON.stringify({ ...Object.fromEntries(entries), [key]: { savedAt: new Date().toISOString(), data } }));
  } catch {
    // The remote result remains usable if local storage is unavailable.
  }
}
