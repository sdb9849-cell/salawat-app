import type { EdgeInsets, Rect } from "react-native-safe-area-context";

export const DEFAULT_WEB_INSETS: EdgeInsets = { top: 0, right: 0, bottom: 0, left: 0 };
export const DEFAULT_WEB_FRAME: Rect = { x: 0, y: 0, width: 0, height: 0 };
