import { createHash, randomBytes, randomUUID, scrypt as nodeScrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import type { Request, Response } from "express";
import { parse as parseCookieHeader } from "cookie";
import { createSalawatSession, createSalawatUser, deleteSalawatSession, getSalawatSessionUser, getUserByEmail } from "../db";
import type { User } from "../../drizzle/schema";

const scrypt = promisify(nodeScrypt);
const SESSION_COOKIE = "salawat_session";
const SESSION_DAYS = 30;

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

async function verifyPassword(password: string, stored: string) {
  const [algorithm, salt, hash] = stored.split("$");
  if (algorithm !== "scrypt" || !salt || !hash) return false;
  const expected = Buffer.from(hash, "hex");
  const actual = (await scrypt(password, salt, expected.length)) as Buffer;
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export function publicUser(user: User) {
  return {
    id: user.id,
    openId: user.openId,
    name: user.name,
    email: user.email,
    loginMethod: "salawat",
    lastSignedIn: user.lastSignedIn.toISOString(),
  };
}

function readToken(req: Request) {
  const authorization = req.headers.authorization;
  if (typeof authorization === "string" && authorization.startsWith("Bearer ")) return authorization.slice(7).trim();
  const cookies = req.headers.cookie ? parseCookieHeader(req.headers.cookie) : {};
  return cookies[SESSION_COOKIE];
}

export async function getSalawatUser(req: Request) {
  const token = readToken(req);
  return token ? getSalawatSessionUser(hashToken(token)) : undefined;
}

export async function registerSalawat(emailInput: string, password: string, name: string) {
  const email = normalizeEmail(emailInput);
  if (!email.includes("@") || email.length > 320) throw new Error("Adresse e-mail invalide");
  if (password.length < 8) throw new Error("Le mot de passe doit contenir au moins 8 caractères");
  if (!name.trim()) throw new Error("Le nom est obligatoire");
  if (await getUserByEmail(email)) throw new Error("Cette adresse e-mail est déjà utilisée");
  const user = await createSalawatUser({
    openId: `salawat:${randomUUID()}`,
    name: name.trim().slice(0, 120),
    email,
    passwordHash: await hashPassword(password),
    loginMethod: "salawat",
    lastSignedIn: new Date(),
  });
  if (!user) throw new Error("Le compte n’a pas pu être créé");
  return user;
}

export async function loginSalawat(emailInput: string, password: string) {
  const user = await getUserByEmail(normalizeEmail(emailInput));
  if (!user?.passwordHash || !(await verifyPassword(password, user.passwordHash))) throw new Error("E-mail ou mot de passe incorrect");
  return user;
}

export async function createSalawatSessionFor(user: User, req: Request, res: Response) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await createSalawatSession(user.id, hashToken(token), expiresAt);
  const secure = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https";
  res.cookie(SESSION_COOKIE, token, { httpOnly: true, sameSite: secure ? "none" : "lax", secure, path: "/", maxAge: SESSION_DAYS * 24 * 60 * 60 * 1000 });
  return token;
}

export async function logoutSalawat(req: Request, res: Response) {
  const token = readToken(req);
  if (token) await deleteSalawatSession(hashToken(token));
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: "lax", secure: req.protocol === "https", path: "/" });
}
