import type { Express, Request, Response } from "express";
import { createSalawatSessionFor, getSalawatUser, loginSalawat, logoutSalawat, publicUser, registerSalawat } from "./salawat-auth";

function bodyString(value: unknown) {
  return typeof value === "string" ? value : "";
}

export function registerSalawatRoutes(app: Express) {
  app.post("/api/salawat-auth/register", async (req: Request, res: Response) => {
    try {
      const user = await registerSalawat(bodyString(req.body?.email), bodyString(req.body?.password), bodyString(req.body?.name));
      const sessionToken = await createSalawatSessionFor(user, req, res);
      res.status(201).json({ sessionToken, user: publicUser(user) });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Inscription impossible" });
    }
  });

  app.post("/api/salawat-auth/login", async (req: Request, res: Response) => {
    try {
      const user = await loginSalawat(bodyString(req.body?.email), bodyString(req.body?.password));
      const sessionToken = await createSalawatSessionFor(user, req, res);
      res.json({ sessionToken, user: publicUser(user) });
    } catch (error) {
      res.status(401).json({ error: error instanceof Error ? error.message : "Connexion impossible" });
    }
  });

  app.get("/api/salawat-auth/me", async (req: Request, res: Response) => {
    const user = await getSalawatUser(req);
    if (!user) {
      res.status(401).json({ user: null });
      return;
    }
    res.json({ user: publicUser(user) });
  });

  app.post("/api/salawat-auth/logout", async (req: Request, res: Response) => {
    await logoutSalawat(req, res);
    res.json({ success: true });
  });
}
