import { eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { announcements, InsertUser, mosques, prayerSchedules, salawatSessions, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch { console.warn("[Database] Failed to connect"); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result[0];
}

export async function createSalawatUser(user: InsertUser) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db.insert(users).values(user);
  const created = await db.select().from(users).where(eq(users.id, result[0].insertId)).limit(1);
  return created[0];
}

export async function createSalawatSession(userId: number, tokenHash: string, expiresAt: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(salawatSessions).values({ userId, tokenHash, expiresAt });
}

export async function getSalawatSessionUser(tokenHash: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select({ user: users, session: salawatSessions })
    .from(salawatSessions)
    .innerJoin(users, eq(salawatSessions.userId, users.id))
    .where(eq(salawatSessions.tokenHash, tokenHash))
    .limit(1);
  const row = result[0];
  if (!row || row.session.expiresAt.getTime() <= Date.now()) return undefined;
  return row.user;
}

export async function deleteSalawatSession(tokenHash: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(salawatSessions).where(eq(salawatSessions.tokenHash, tokenHash));
}

export async function listPublishedMosques(query?: string) {
  const db = await getDb();
  if (!db) return [];
  const normalized = query?.trim();
  const result = normalized
    ? await db.select().from(mosques).where(or(like(mosques.name, `%${normalized}%`), like(mosques.city, `%${normalized}%`), like(mosques.country, `%${normalized}%`))).limit(50)
    : await db.select().from(mosques).limit(50);
  return result.filter((mosque) => mosque.status === "published");
}

export async function getMosqueSchedule(mosqueId: number, date: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(prayerSchedules).where(eq(prayerSchedules.mosqueId, mosqueId)).limit(20);
  return result.find((schedule) => schedule.scheduleDate === date) ?? result[0];
}

export async function getMosqueAnnouncements(mosqueId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(announcements).where(eq(announcements.mosqueId, mosqueId)).limit(20);
}
