export type PrayerTimeName = "Fajr" | "Dhuhr" | "Asr" | "Maghrib" | "Isha";

export type PrayerTimeEntry = {
  name: PrayerTimeName;
  arabic: string;
  time: string;
  state: "done" | "next" | "upcoming";
};

export type PrayerTimesResult = {
  date: string;
  timezone: string;
  method: number;
  methodName: string;
  prayers: PrayerTimeEntry[];
};

const PRAYER_LABELS: Record<PrayerTimeName, string> = {
  Fajr: "الفجر",
  Dhuhr: "الظهر",
  Asr: "العصر",
  Maghrib: "المغرب",
  Isha: "العشاء",
};

const COUNTRY_METHODS: Record<string, { id: number; name: string }> = {
  DZ: { id: 19, name: "Algérie" },
  FR: { id: 12, name: "France" },
  ID: { id: 20, name: "Indonésie" },
  MA: { id: 21, name: "Maroc" },
  MY: { id: 17, name: "Malaisie" },
  PK: { id: 1, name: "Karachi" },
  SG: { id: 11, name: "Singapour" },
  TN: { id: 18, name: "Tunisie" },
  TR: { id: 13, name: "Turquie" },
  US: { id: 2, name: "ISNA" },
  CA: { id: 2, name: "ISNA" },
};
const DEFAULT_METHOD = { id: 3, name: "Muslim World League" };
const ARABIC_DATE_LABELS: Record<PrayerTimeName, string> = PRAYER_LABELS;
const PRAYER_NAMES: PrayerTimeName[] = [
  "Fajr",
  "Dhuhr",
  "Asr",
  "Maghrib",
  "Isha",
];

type AladhanResponse = {
  code?: number;
  status?: string;
  data?: {
    timings?: Partial<Record<PrayerTimeName, string>>;
    date?: { gregorian?: { date?: string } };
    meta?: { timezone?: string };
  };
};

function validateDate(date: string) {
  const match = /^(\d{2})-(\d{2})-(\d{4})$/.exec(date);
  if (!match)
    throw new Error("La date des horaires doit être au format JJ-MM-AAAA.");
  const [, day, month, year] = match;
  const parsed = new Date(
    Date.UTC(Number(year), Number(month) - 1, Number(day)),
  );
  if (
    parsed.getUTCFullYear() !== Number(year) ||
    parsed.getUTCMonth() !== Number(month) - 1 ||
    parsed.getUTCDate() !== Number(day)
  ) {
    throw new Error("La date demandée pour les horaires est invalide.");
  }
}

function normalizeTime(value: string | undefined, name: PrayerTimeName) {
  const time = value?.split(/[\s(]/, 1)[0];
  if (!time || !/^\d{1,2}:\d{2}$/.test(time)) {
    throw new Error(
      `La réponse Aladhan ne contient pas d’horaire valide pour ${name}.`,
    );
  }
  const [hour, minute] = time.split(":").map(Number);
  if (hour > 23 || minute > 59)
    throw new Error(`Horaire Aladhan invalide pour ${name}.`);
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

/** Appelé côté serveur uniquement : aucune clé fournisseur n’est nécessaire dans l’application mobile. */
export async function fetchPrayerTimes(input: {
  latitude: number;
  longitude: number;
  date: string;
  countryCode?: string;
  school?: 0 | 1;
}): Promise<PrayerTimesResult> {
  const { latitude, longitude, date, countryCode, school = 0 } = input;
  if (
    !Number.isFinite(latitude) ||
    latitude < -90 ||
    latitude > 90 ||
    !Number.isFinite(longitude) ||
    longitude < -180 ||
    longitude > 180
  ) {
    throw new Error("Coordonnées GPS invalides pour le calcul des horaires.");
  }
  validateDate(date);
  const method =
    (countryCode && COUNTRY_METHODS[countryCode.toUpperCase()]) ||
    DEFAULT_METHOD;
  const params = new URLSearchParams({
    latitude: String(latitude),
    longitude: String(longitude),
    method: String(method.id),
    school: String(school),
  });
  const url = `https://api.aladhan.com/v1/timings/${date}?${params.toString()}`;

  let response: Response;
  try {
    response = await fetch(url, {
      headers: {
        Accept: "application/json",
        "User-Agent": "Salawat/1.0 (prayer times)",
      },
      signal: AbortSignal.timeout(12_000),
    });
  } catch (error) {
    const reason =
      error instanceof Error && error.name === "TimeoutError"
        ? "Aladhan ne répond pas dans le délai prévu."
        : "Impossible de joindre le service des horaires de prière.";
    throw new Error(reason);
  }
  if (!response.ok)
    throw new Error(
      `Le service Aladhan a répondu avec le code HTTP ${response.status}.`,
    );

  let payload: AladhanResponse;
  try {
    payload = (await response.json()) as AladhanResponse;
  } catch {
    throw new Error("La réponse Aladhan n’est pas un JSON valide.");
  }
  if (payload.code !== 200 || !payload.data?.timings) {
    throw new Error(
      `Aladhan n’a pas fourni les horaires demandés${payload.status ? ` (${payload.status})` : ""}.`,
    );
  }

  return {
    date: payload.data.date?.gregorian?.date ?? date,
    timezone: payload.data.meta?.timezone ?? "",
    method: method.id,
    methodName: method.name,
    prayers: PRAYER_NAMES.map((name) => ({
      name,
      arabic: ARABIC_DATE_LABELS[name],
      time: normalizeTime(payload.data?.timings?.[name], name),
      state: "upcoming",
    })),
  };
}
