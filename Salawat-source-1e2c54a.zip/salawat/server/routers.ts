import { z } from "zod";
import {
  announcements,
  mosques as mosquesTable,
  prayerSchedules,
} from "../drizzle/schema";
import {
  getMosqueAnnouncements,
  getMosqueSchedule,
  getDb,
  listPublishedMosques,
} from "./db";
import { getSessionCookieName, getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { fetchPrayerTimes } from "./prayer-times";

const fallbackReciters = [
  {
    identifier: "ar.alafasy",
    name: "مشاري راشد العفاسي",
    englishName: "Mishary Rashid Alafasy",
    style: "Murattal",
  },
  {
    identifier: "ar.husary",
    name: "محمود خليل الحصري",
    englishName: "Mahmoud Khalil Al-Husary",
    style: "Murattal",
  },
  {
    identifier: "ar.minshawi",
    name: "محمد صديق المنشاوي",
    englishName: "Mohamed Siddiq Al-Minshawi",
    style: "Murattal",
  },
  {
    identifier: "ar.sudais",
    name: "عبد الرحمن السديس",
    englishName: "Abdul Rahman Al-Sudais",
    style: "Murattal",
  },
  {
    identifier: "ar.shuraim",
    name: "سعود الشريم",
    englishName: "Saud Al-Shuraim",
    style: "Murattal",
  },
  {
    identifier: "ar.abdulbasit",
    name: "عبد الباسط عبد الصمد",
    englishName: "Abdul Basit Abdul Samad",
    style: "Murattal",
  },
  {
    identifier: "ar.ajamy",
    name: "أحمد بن علي العجمي",
    englishName: "Ahmed Al-Ajamy",
    style: "Murattal",
  },
  {
    identifier: "ar.hudhaify",
    name: "علي الحذيفي",
    englishName: "Ali Al-Hudhaify",
    style: "Murattal",
  },
];

async function fetchJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: { "User-Agent": "Salawat/1.0 Quran reader" },
  });
  if (!response.ok) throw new Error(`Quran source returned ${response.status}`);
  return response.json() as Promise<T>;
}

type OverpassElement = {
  type: "node" | "way" | "relation";
  id: number;
  lat?: number;
  lon?: number;
  center?: { lat: number; lon: number };
  tags?: Record<string, string>;
};

function distanceMeters(
  latitude: number,
  longitude: number,
  targetLatitude: number,
  targetLongitude: number,
) {
  const radius = 6371000;
  const lat1 = (latitude * Math.PI) / 180;
  const lat2 = (targetLatitude * Math.PI) / 180;
  const dLat = ((targetLatitude - latitude) * Math.PI) / 180;
  const dLon = ((targetLongitude - longitude) * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return Math.round(2 * radius * Math.asin(Math.sqrt(h)));
}

function formatDistance(meters: number) {
  return meters < 1000
    ? `${meters} m`
    : `${(meters / 1000).toFixed(meters >= 10000 ? 0 : 1).replace(".", ",")} km`;
}

const OVERPASS_ENDPOINTS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
];

type NominatimMosque = {
  place_id: number;
  osm_type?: string;
  osm_id?: number;
  lat: string;
  lon: string;
  name?: string;
  display_name: string;
};

async function findNominatimMosques(
  latitude: number,
  longitude: number,
  radiusMeters: number,
) {
  const latitudeDelta = radiusMeters / 111_000;
  const longitudeDelta =
    radiusMeters /
    (111_000 * Math.max(0.2, Math.cos((latitude * Math.PI) / 180)));
  const viewbox = [
    longitude - longitudeDelta,
    latitude + latitudeDelta,
    longitude + longitudeDelta,
    latitude - latitudeDelta,
  ].join(",");
  const params = new URLSearchParams({
    format: "jsonv2",
    limit: "50",
    bounded: "1",
    viewbox,
    q: "mosquée",
    "accept-language": "fr",
  });
  const response = await fetch(
    `https://nominatim.openstreetmap.org/search?${params.toString()}`,
    {
      headers: {
        Accept: "application/json",
        "User-Agent": "Salawat/1.0 (mosque discovery)",
      },
      signal: AbortSignal.timeout(10_000),
    },
  );
  if (!response.ok)
    throw new Error(`Nominatim a répondu avec le code HTTP ${response.status}.`);
  const results = (await response.json()) as NominatimMosque[];
  const seen = new Set<string>();
  return results
    .flatMap((result) => {
      const point = {
        latitude: Number(result.lat),
        longitude: Number(result.lon),
      };
      if (!Number.isFinite(point.latitude) || !Number.isFinite(point.longitude))
        return [];
      const distance = distanceMeters(
        latitude,
        longitude,
        point.latitude,
        point.longitude,
      );
      if (distance > radiusMeters) return [];
      const name = result.name?.trim() || result.display_name.split(",")[0]?.trim();
      if (!name) return [];
      const key = `${Math.round(point.latitude * 100000)}:${Math.round(point.longitude * 100000)}:${name.toLowerCase()}`;
      if (seen.has(key)) return [];
      seen.add(key);
      return [
        {
          id: `osm-${result.osm_type ?? "place"}-${result.osm_id ?? result.place_id}`,
          source: "osm" as const,
          sourceId: `${result.osm_type ?? "place"}/${result.osm_id ?? result.place_id}`,
          name,
          city: "À proximité",
          country: "",
          address: result.display_name || "Adresse non renseignée",
          latitude: point.latitude,
          longitude: point.longitude,
          distanceMeters: distance,
          distance: formatDistance(distance),
          verified: false,
          openNow: false,
          services: ["Mosquée"],
          nextPrayer: "Horaires à vérifier",
          imageTone: "#DDF1EA",
          sourceLabel: "OpenStreetMap · repli Nominatim",
        },
      ];
    })
    .sort((a, b) => a.distanceMeters - b.distanceMeters);
}

async function findNearbyOsmMosques(
  latitude: number,
  longitude: number,
  radiusMeters: number,
) {
  if (
    !Number.isFinite(latitude) ||
    latitude < -90 ||
    latitude > 90 ||
    !Number.isFinite(longitude) ||
    longitude < -180 ||
    longitude > 180
  ) {
    throw new Error("Coordonnées GPS invalides pour la recherche de mosquées.");
  }
  const query = `[out:json][timeout:10];(nwr[amenity=place_of_worship][religion~"^(muslim|islam)$"](around:${radiusMeters},${latitude},${longitude});nwr[place_of_worship=musalla](around:${radiusMeters},${latitude},${longitude});nwr[building=mosque](around:${radiusMeters},${latitude},${longitude}););out center tags;`;
  let payload: { elements?: OverpassElement[] } | null = null;
  let lastError: unknown;
  for (const endpoint of OVERPASS_ENDPOINTS) {
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "text/plain; charset=utf-8",
          Accept: "application/json",
          "User-Agent": "Salawat/1.0 (mosque discovery)",
        },
        body: query,
        signal: AbortSignal.timeout(12_000),
      });
      if (!response.ok)
        throw new Error(
          `OpenStreetMap a répondu avec le code HTTP ${response.status}.`,
        );
      const result = (await response.json()) as {
        elements?: OverpassElement[];
        remark?: string;
      };
      if (result.remark) throw new Error(`OpenStreetMap : ${result.remark}`);
      if (!Array.isArray(result.elements))
        throw new Error("La réponse OpenStreetMap n’a pas le format attendu.");
      payload = result;
      break;
    } catch (error) {
      lastError = error;
    }
  }
  if (!payload) {
    try {
      return await findNominatimMosques(latitude, longitude, radiusMeters);
    } catch (fallbackError) {
      throw new Error(
        `Les services OpenStreetMap sont temporairement indisponibles. ${
          lastError instanceof Error ? lastError.message : "Erreur réseau inconnue."
        } ${
          fallbackError instanceof Error
            ? fallbackError.message
            : "Le repli Nominatim a également échoué."
        }`,
      );
    }
  }
  const seen = new Set<string>();
  const overpassMosques = (payload.elements ?? [])
    .flatMap((element) => {
      const point =
        element.lat != null && element.lon != null
          ? { latitude: element.lat, longitude: element.lon }
          : element.center
            ? { latitude: element.center.lat, longitude: element.center.lon }
            : null;
      const tags = element.tags ?? {};
      const name =
        tags.name?.trim() ||
        tags["name:fr"]?.trim() ||
        tags["name:ar"]?.trim() ||
        tags["official_name"]?.trim();
      if (!point || !name) return [];
      const key = `${Math.round(point.latitude * 100000)}:${Math.round(point.longitude * 100000)}:${name.toLowerCase()}`;
      if (seen.has(key)) return [];
      seen.add(key);
      const distance = distanceMeters(
        latitude,
        longitude,
        point.latitude,
        point.longitude,
      );
      const services = [
        tags["place_of_worship"] === "musalla" ? "Salle de prière" : "Mosquée",
        tags.wheelchair === "yes" ? "PMR" : null,
        tags["opening_hours"] ? "Horaires renseignés" : null,
      ].filter((item): item is string => Boolean(item));
      return [
        {
          id: `osm-${element.type}-${element.id}`,
          source: "osm" as const,
          sourceId: `${element.type}/${element.id}`,
          name,
          city: tags["addr:city"] ?? tags["addr:suburb"] ?? "À proximité",
          country: tags["addr:country"] ?? "",
          address:
            [
              tags["addr:housenumber"],
              tags["addr:street"],
              tags["addr:postcode"],
              tags["addr:city"],
            ]
              .filter(Boolean)
              .join(" ") || "Adresse non renseignée",
          latitude: point.latitude,
          longitude: point.longitude,
          distanceMeters: distance,
          distance: formatDistance(distance),
          verified: false,
          openNow: tags["opening_hours"] === "24/7",
          services,
          nextPrayer: "Horaires à vérifier",
          imageTone: "#DDF1EA",
          sourceLabel: "OpenStreetMap",
        },
      ];
    })
    .sort((a, b) => a.distanceMeters - b.distanceMeters);
  if (overpassMosques.length > 0) return overpassMosques;
  try {
    return await findNominatimMosques(latitude, longitude, radiusMeters);
  } catch {
    return overpassMosques;
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(getSessionCookieName(ctx.req), {
        ...cookieOptions,
        maxAge: -1,
      });
      return { success: true } as const;
    }),
  }),
  mosques: router({
    list: publicProcedure
      .input(z.object({ query: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return listPublishedMosques(input?.query);
      }),
    nearby: publicProcedure
      .input(
        z.object({
          latitude: z.number().min(-90).max(90),
          longitude: z.number().min(-180).max(180),
          radiusMeters: z.number().int().min(500).max(20000).default(5000),
        }),
      )
      .query(async ({ input }) =>
        findNearbyOsmMosques(
          input.latitude,
          input.longitude,
          input.radiusMeters,
        ),
      ),
    searchLocation: publicProcedure
      .input(z.object({ query: z.string().min(2).max(120) }))
      .query(async ({ input }) => {
        const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&accept-language=fr&q=${encodeURIComponent(input.query)}`;
        const response = await fetch(url, {
          headers: { "User-Agent": "Salawat/1.0 (manual location search)" },
        });
        if (!response.ok)
          throw new Error(`Location search returned ${response.status}`);
        const results = (await response.json()) as Array<{
          lat: string;
          lon: string;
          display_name: string;
        }>;
        const result = results[0];
        if (!result) return null;
        return {
          latitude: Number(result.lat),
          longitude: Number(result.lon),
          label: result.display_name,
        };
      }),
    prayerTimes: publicProcedure
      .input(
        z.object({
          latitude: z.number().min(-90).max(90),
          longitude: z.number().min(-180).max(180),
          date: z.string().regex(/^\d{2}-\d{2}-\d{4}$/),
          countryCode: z.string().length(2).optional(),
          school: z.union([z.literal(0), z.literal(1)]).default(0),
        }),
      )
      .query(({ input }) => fetchPrayerTimes(input)),
    schedule: publicProcedure
      .input(z.object({ mosqueId: z.number(), date: z.string() }))
      .query(({ input }) => getMosqueSchedule(input.mosqueId, input.date)),
    announcements: publicProcedure
      .input(z.object({ mosqueId: z.number() }))
      .query(({ input }) => getMosqueAnnouncements(input.mosqueId)),
  }),
  quran: router({
    surahs: publicProcedure.query(async () => {
      const response = await fetchJson<{
        data: Array<{
          number: number;
          name: string;
          englishName: string;
          englishNameTranslation: string;
          numberOfAyahs: number;
          revelationType: string;
        }>;
      }>("https://api.alquran.cloud/v1/surah");
      return response.data;
    }),
    reciters: publicProcedure.query(async () => {
      try {
        const response = await fetchJson<{
          data: Array<{
            identifier: string;
            language: string;
            name: string;
            englishName: string;
            format: string;
            type: string;
          }>;
        }>("https://api.alquran.cloud/v1/edition/format/audio");
        const reciters = response.data
          .filter(
            (edition) =>
              edition.language === "ar" && edition.format === "audio",
          )
          .map((edition) => ({
            identifier: edition.identifier,
            name: edition.name,
            englishName: edition.englishName,
            style: edition.type,
          }))
          .filter(
            (edition, index, all) =>
              all.findIndex(
                (item) => item.identifier === edition.identifier,
              ) === index,
          );
        return reciters.length > 0 ? reciters : fallbackReciters;
      } catch {
        return fallbackReciters;
      }
    }),
    surah: publicProcedure
      .input(z.object({ number: z.number().int().min(1).max(114) }))
      .query(async ({ input }) => {
        const [arabic, french] = await Promise.all([
          fetchJson<{
            data: {
              name: string;
              englishName: string;
              numberOfAyahs: number;
              ayahs: Array<{ numberInSurah: number; text: string }>;
            };
          }>(`https://api.alquran.cloud/v1/surah/${input.number}/quran-simple`),
          fetchJson<{
            result: Array<{
              aya: string;
              arabic_text: string;
              translation: string;
              footnotes?: string;
            }>;
          }>(
            `https://quranenc.com/api/v1/translation/sura/french_rashid/${input.number}`,
          ),
        ]);
        return {
          number: input.number,
          name: arabic.data.name,
          englishName: arabic.data.englishName,
          numberOfAyahs: arabic.data.numberOfAyahs,
          source:
            "Texte arabe : Al Quran Cloud, édition quran-simple · Traduction française : QuranEnc, Rachid Maach, version 1.0.3",
          verses: arabic.data.ayahs.map((ayah, index) => ({
            number: ayah.numberInSurah,
            arabic: ayah.text,
            translation: french.result[index]?.translation ?? "",
            footnotes: french.result[index]?.footnotes ?? "",
          })),
        };
      }),
  }),
  management: router({
    snapshot: adminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      const owned = db ? await db.select().from(mosquesTable).limit(1) : [];
      return {
        user: ctx.user,
        mosque: owned[0] ?? null,
        counts: { publishedPrayerSlots: 5, activeMembers: 18, completion: 92 },
      };
    }),
    publishSchedule: adminProcedure
      .input(
        z.object({
          mosqueId: z.number(),
          date: z.string(),
          fajr: z.string(),
          dhuhr: z.string(),
          asr: z.string(),
          maghrib: z.string(),
          isha: z.string(),
        }),
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db)
          return { success: false, reason: "database-unavailable" as const };
        await db.insert(prayerSchedules).values({
          mosqueId: input.mosqueId,
          scheduleDate: input.date,
          fajr: input.fajr,
          dhuhr: input.dhuhr,
          asr: input.asr,
          maghrib: input.maghrib,
          isha: input.isha,
          published: 1,
        });
        return { success: true as const };
      }),
    createAnnouncement: adminProcedure
      .input(
        z.object({
          mosqueId: z.number(),
          title: z.string().min(2),
          body: z.string().min(2),
        }),
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db)
          return { success: false, reason: "database-unavailable" as const };
        await db
          .insert(announcements)
          .values({ ...input, status: "published", publishedAt: new Date() });
        return { success: true as const };
      }),
  }),
});

export type AppRouter = typeof appRouter;
