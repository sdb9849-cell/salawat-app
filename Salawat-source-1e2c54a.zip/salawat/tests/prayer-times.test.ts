import { afterEach, describe, expect, it, vi } from "vitest";
import { fetchPrayerTimes } from "../server/prayer-times";

const apiPayload = {
  code: 200,
  status: "OK",
  data: {
    timings: {
      Fajr: "05:34 (CET)",
      Dhuhr: "12:05 (CET)",
      Asr: "14:47 (CET)",
      Maghrib: "17:06 (CET)",
      Isha: "18:37 (CET)",
    },
    date: { gregorian: { date: "22-11-2026" } },
    meta: { timezone: "Africa/Tunis" },
  },
};

afterEach(() => vi.unstubAllGlobals());

describe("fetchPrayerTimes", () => {
  it("transmet les coordonnées GPS et choisit la méthode tunisienne", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(
        new Response(JSON.stringify(apiPayload), { status: 200 }),
      );
    vi.stubGlobal("fetch", fetchMock);

    const result = await fetchPrayerTimes({
      latitude: 36.8065,
      longitude: 10.1815,
      date: "22-11-2026",
      countryCode: "TN",
    });
    const requestUrl = new URL(fetchMock.mock.calls[0][0] as string);

    expect(requestUrl.searchParams.get("latitude")).toBe("36.8065");
    expect(requestUrl.searchParams.get("longitude")).toBe("10.1815");
    expect(requestUrl.searchParams.get("method")).toBe("18");
    expect(result.timezone).toBe("Africa/Tunis");
    expect(result.prayers).toHaveLength(5);
    expect(result.prayers[0]).toMatchObject({ name: "Fajr", time: "05:34" });
  });

  it("sélectionne la méthode marocaine pour le Maroc", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(
        new Response(JSON.stringify(apiPayload), { status: 200 }),
      );
    vi.stubGlobal("fetch", fetchMock);

    await fetchPrayerTimes({
      latitude: 33.9716,
      longitude: -6.8498,
      date: "22-11-2026",
      countryCode: "MA",
    });

    expect(
      new URL(fetchMock.mock.calls[0][0] as string).searchParams.get("method"),
    ).toBe("21");
  });

  it("refuse une date impossible avant tout appel réseau", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      fetchPrayerTimes({ latitude: 36.8, longitude: 10.1, date: "31-02-2026" }),
    ).rejects.toThrow("date demandée");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("refuse les coordonnées hors limites", async () => {
    await expect(
      fetchPrayerTimes({ latitude: 91, longitude: 0, date: "22-11-2026" }),
    ).rejects.toThrow("Coordonnées GPS invalides");
  });
});
