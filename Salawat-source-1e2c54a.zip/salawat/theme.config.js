/** @type {const} */
const themeColors = {
  primary: { light: '#0F6B58', dark: '#77C9B0' },
  background: { light: '#F8FAF7', dark: '#10231F' },
  surface: { light: '#FFFFFF', dark: '#17332D' },
  foreground: { light: '#17332D', dark: '#F5FAF7' },
  muted: { light: '#6C817A', dark: '#A5B9B1' },
  border: { light: '#DCE8E2', dark: '#2C4A42' },
  success: { light: '#208467', dark: '#77C9B0' },
  warning: { light: '#C99A3D', dark: '#F0D38A' },
  error: { light: '#B84A4A', dark: '#F28B8B' },
};

module.exports = { themeColors };
